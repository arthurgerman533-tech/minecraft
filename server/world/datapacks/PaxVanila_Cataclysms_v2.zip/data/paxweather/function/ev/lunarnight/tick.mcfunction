execute as @a[tag=pxw_moon,tag=pxw_sout] at @s run particle minecraft:white_ash ~ ~2 ~ 6 2 6 0 40 normal @s
execute as @a[tag=pxw_moon,tag=pxw_sout,predicate=!paxweather:warm] run effect give @s minecraft:slowness 3 0 true
execute if score #m15 pxw matches 0 run effect give @a[tag=pxw_moon,tag=pxw_sout] minecraft:darkness 4 0 true
execute if score #m10 pxw matches 0 as @a[tag=pxw_moon,tag=pxw_sout,predicate=!paxweather:warm] at @s run function paxweather:ev/lunarnight/cold
