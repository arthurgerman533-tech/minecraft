tellraw @a [{"text": "❄ ", "color": "aqua"}, {"text": "Метель. ", "color": "aqua", "bold": true}, {"text": "С севера идёт метель. Через минуту холод: нужна крыша или кожаная броня.", "color": "gray"}]
execute as @a at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 0.6 0.6
