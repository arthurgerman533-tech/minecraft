$execute store result score #next pxw run random value $(min)..$(max)
