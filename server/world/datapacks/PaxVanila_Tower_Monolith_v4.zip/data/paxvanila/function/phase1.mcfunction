execute store result storage paxvanila:t a.y int 1 run scoreboard players get #g pxt
data modify storage paxvanila:t a.f set value "clear"
function paxvanila:at with storage paxvanila:t a
execute store result storage paxvanila:t a.y int 1 run scoreboard players get #g pxt
data modify storage paxvanila:t a.f set value "foundation"
function paxvanila:at with storage paxvanila:t a
execute store result storage paxvanila:t a.y int 1 run scoreboard players get #g pxt
data modify storage paxvanila:t a.f set value "base"
function paxvanila:at with storage paxvanila:t a
scoreboard players operation #y pxt = #g pxt
scoreboard players add #y pxt 1
scoreboard players set #done pxt 0
schedule function paxvanila:loop 2t replace
