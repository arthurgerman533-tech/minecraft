scoreboard players remove #next pxw 1
execute if score #next pxw matches ..0 run function paxweather:core/auto_roll
