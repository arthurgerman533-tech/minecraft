setblock ~0 ~0 ~10 minecraft:iron_bars
setblock ~0 ~0 ~11 minecraft:iron_bars
setblock ~0 ~0 ~-10 minecraft:iron_bars
setblock ~0 ~0 ~-11 minecraft:iron_bars
setblock ~10 ~0 ~0 minecraft:iron_bars
setblock ~11 ~0 ~0 minecraft:iron_bars
setblock ~-10 ~0 ~0 minecraft:iron_bars
setblock ~-11 ~0 ~0 minecraft:iron_bars
