execute store result storage paxvanila:t a.y int 1 run scoreboard players get #g pxt
data modify storage paxvanila:t a.f set value "hall"
function paxvanila:at with storage paxvanila:t a
execute in minecraft:overworld run forceload remove -32 -32 31 31
tellraw @a [{"text":"[Башня] ","color":"gold"},{"text":"Зал пяти народов, надпись PAX и Корни готовы.","color":"green"}]
