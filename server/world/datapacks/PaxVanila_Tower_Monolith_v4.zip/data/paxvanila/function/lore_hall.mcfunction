scoreboard objectives add pxt dummy
execute unless score #g pxt = #g pxt run return run tellraw @s {"text":"[Башня] Сначала построй башню.","color":"red"}
execute in minecraft:overworld run forceload add -32 -32 31 31
schedule function paxvanila:lore_hall2 10t replace
tellraw @s [{"text":"[Башня] ","color":"gold"},{"text":"Обставляю зал Предтеч...","color":"yellow"}]
