execute as @a[tag=pxw_out] at @s run particle minecraft:snowflake ~ ~3 ~ 7 3 7 0.03 70 normal @s
execute as @a[tag=pxw_out] at @s run particle minecraft:white_ash ~ ~2 ~ 6 2 6 0 40 normal @s
execute as @a[tag=pxw_out,predicate=!paxweather:warm] run effect give @s minecraft:slowness 3 0 true
execute if score #m10 pxw matches 0 as @a[tag=pxw_out,predicate=!paxweather:warm] at @s run function paxweather:ev/blizzard/cold
execute if score #m30 pxw matches 0 store result score #cnt pxw if entity @e[type=minecraft:stray,tag=pxw_mob]
execute if score #m30 pxw matches 0 if score #cnt pxw matches ..9 as @a[tag=pxw_adult,tag=pxw_out,sort=random,limit=2] at @s run function paxweather:ev/blizzard/mob
