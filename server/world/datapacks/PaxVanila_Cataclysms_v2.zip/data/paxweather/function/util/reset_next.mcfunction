function paxweather:util/reset_next_m with storage paxweather:cfg
