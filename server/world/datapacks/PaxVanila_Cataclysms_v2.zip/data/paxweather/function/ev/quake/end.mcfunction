tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Земля успокоилась. Проверьте шахты.", "color": "green"}]
