execute in minecraft:overworld positioned 96 0 0 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 89 0 37 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 68 0 68 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 37 0 89 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 0 0 96 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -37 0 89 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -68 0 68 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -89 0 37 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -96 0 0 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -89 0 -37 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -68 0 -68 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -37 0 -89 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 0 0 -96 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 37 0 -89 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 68 0 -68 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 89 0 -37 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
schedule function paxvanila:probe/r4 4t replace
