execute in paxweather:mars run tp @s 0 -3 0
tellraw @s [{"text": "[Космос] ", "color": "aqua"}, {"text": "Марс. Гравитация 3/8, красная пыль. Назад: /function paxweather:go_earth", "color": "gray"}]
