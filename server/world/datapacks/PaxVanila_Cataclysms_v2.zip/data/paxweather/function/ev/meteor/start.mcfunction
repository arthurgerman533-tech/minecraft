execute store result score #time pxw run random value 120..180
bossbar set paxweather:event name {"text": "☄ Звёздный дождь", "color": "light_purple"}
bossbar set paxweather:event color purple
title @a times 10 50 20
title @a subtitle {"text": "Звёздный дождь! Метеориты падают рядом с игроками: в них лут и Звёздные осколки.", "color": "gray"}
title @a title {"text": "☄ Звёздный дождь", "color": "light_purple", "bold": true}
tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Звёздный дождь! Метеориты падают рядом с игроками: в них лут и Звёздные осколки.", "color": "light_purple"}]
weather clear 600s
