tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Метеоритный шторм прошёл. Собирайте осколки.", "color": "green"}]
