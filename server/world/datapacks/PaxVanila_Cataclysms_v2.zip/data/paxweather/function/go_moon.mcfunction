execute in paxweather:moon run tp @s 0 -3 0
tellraw @s [{"text": "[Космос] ", "color": "aqua"}, {"text": "Луна. Гравитация 1/6, небо чёрное, под ногами реголит. Назад: /function paxweather:go_earth", "color": "gray"}]
