give @s minecraft:stone_spear[minecraft:custom_name={text:"Копьё морехода",italic:false}] 1
give @s minecraft:stone_axe[minecraft:custom_name={text:"Топор морехода",italic:false}] 1
give @s minecraft:cooked_cod 8
give @s minecraft:lead[minecraft:custom_name={text:"Морской канат",italic:false}] 2
give @s minecraft:map 1
give @s minecraft:oak_boat 1
give @s minecraft:bucket 1
give @s minecraft:spyglass 1
give @s minecraft:written_book[minecraft:written_book_content={title:'Слово о PAX',author:'Учёные Ромеи',pages:['СЛОВО О PAX\n\nНа 0, 0 стоит Монолит. Это печать над Великими вратами, которые погубили Предтеч в Год Пепла.','Пять народов Предтеч:\nНарод Глубин, Ур-Кадим, Нэферу, Талассия и Медный Союз Каэр-Тала.\nА до них Те, Кого Нет.','Ромул прочёл на башне слово PAX и основал Священную Ромейскую Республику. С тех пор державы растут вокруг печати.','Закон мира:\nвойна только за 24 часа и с причиной;\nне сносить города в ноль;\nновичков не трогать 48 часов.\n\nЗайди в башню и прочти кафедры.']}] 1
tellraw @s [{"text":"[PaxVanila] ","color":"gold"},{"text":"Ты получил набор морехода и книгу «Слово о PAX». Монолит на 0, 0 хранит память Предтеч: загляни внутрь. Удачи в плавании!","color":"aqua"}]
