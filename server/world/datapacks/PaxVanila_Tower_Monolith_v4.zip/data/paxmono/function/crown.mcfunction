fill ~-11 ~1 ~-5 ~-11 ~1 ~5 minecraft:polished_blackstone_bricks
fill ~-10 ~1 ~-6 ~-10 ~1 ~-6 minecraft:polished_blackstone_bricks
fill ~-10 ~1 ~6 ~-10 ~1 ~6 minecraft:polished_blackstone_bricks
fill ~-9 ~1 ~-7 ~-9 ~1 ~-7 minecraft:polished_blackstone_bricks
fill ~-9 ~1 ~7 ~-9 ~1 ~7 minecraft:polished_blackstone_bricks
fill ~-8 ~1 ~-8 ~-8 ~1 ~-8 minecraft:polished_blackstone_bricks
fill ~-8 ~1 ~8 ~-8 ~1 ~8 minecraft:polished_blackstone_bricks
fill ~-7 ~1 ~-9 ~-7 ~1 ~-9 minecraft:polished_blackstone_bricks
fill ~-7 ~1 ~9 ~-7 ~1 ~9 minecraft:polished_blackstone_bricks
fill ~-6 ~1 ~-10 ~-6 ~1 ~-10 minecraft:polished_blackstone_bricks
fill ~-6 ~1 ~10 ~-6 ~1 ~10 minecraft:polished_blackstone_bricks
fill ~-5 ~1 ~-11 ~-5 ~1 ~-11 minecraft:polished_blackstone_bricks
fill ~-5 ~1 ~11 ~-5 ~1 ~11 minecraft:polished_blackstone_bricks
fill ~-4 ~1 ~-11 ~-4 ~1 ~-11 minecraft:polished_blackstone_bricks
fill ~-4 ~1 ~11 ~-4 ~1 ~11 minecraft:polished_blackstone_bricks
fill ~-3 ~1 ~-11 ~-3 ~1 ~-11 minecraft:polished_blackstone_bricks
fill ~-3 ~1 ~11 ~-3 ~1 ~11 minecraft:polished_blackstone_bricks
fill ~-2 ~1 ~-11 ~-2 ~1 ~-11 minecraft:polished_blackstone_bricks
fill ~-2 ~1 ~11 ~-2 ~1 ~11 minecraft:polished_blackstone_bricks
fill ~-1 ~1 ~-11 ~-1 ~1 ~-11 minecraft:polished_blackstone_bricks
fill ~-1 ~1 ~11 ~-1 ~1 ~11 minecraft:polished_blackstone_bricks
fill ~0 ~1 ~-11 ~0 ~1 ~-11 minecraft:polished_blackstone_bricks
fill ~0 ~1 ~11 ~0 ~1 ~11 minecraft:polished_blackstone_bricks
fill ~1 ~1 ~-11 ~1 ~1 ~-11 minecraft:polished_blackstone_bricks
fill ~1 ~1 ~11 ~1 ~1 ~11 minecraft:polished_blackstone_bricks
fill ~2 ~1 ~-11 ~2 ~1 ~-11 minecraft:polished_blackstone_bricks
fill ~2 ~1 ~11 ~2 ~1 ~11 minecraft:polished_blackstone_bricks
fill ~3 ~1 ~-11 ~3 ~1 ~-11 minecraft:polished_blackstone_bricks
fill ~3 ~1 ~11 ~3 ~1 ~11 minecraft:polished_blackstone_bricks
fill ~4 ~1 ~-11 ~4 ~1 ~-11 minecraft:polished_blackstone_bricks
fill ~4 ~1 ~11 ~4 ~1 ~11 minecraft:polished_blackstone_bricks
fill ~5 ~1 ~-11 ~5 ~1 ~-11 minecraft:polished_blackstone_bricks
fill ~5 ~1 ~11 ~5 ~1 ~11 minecraft:polished_blackstone_bricks
fill ~6 ~1 ~-10 ~6 ~1 ~-10 minecraft:polished_blackstone_bricks
fill ~6 ~1 ~10 ~6 ~1 ~10 minecraft:polished_blackstone_bricks
fill ~7 ~1 ~-9 ~7 ~1 ~-9 minecraft:polished_blackstone_bricks
fill ~7 ~1 ~9 ~7 ~1 ~9 minecraft:polished_blackstone_bricks
fill ~8 ~1 ~-8 ~8 ~1 ~-8 minecraft:polished_blackstone_bricks
fill ~8 ~1 ~8 ~8 ~1 ~8 minecraft:polished_blackstone_bricks
fill ~9 ~1 ~-7 ~9 ~1 ~-7 minecraft:polished_blackstone_bricks
fill ~9 ~1 ~7 ~9 ~1 ~7 minecraft:polished_blackstone_bricks
fill ~10 ~1 ~-6 ~10 ~1 ~-6 minecraft:polished_blackstone_bricks
fill ~10 ~1 ~6 ~10 ~1 ~6 minecraft:polished_blackstone_bricks
fill ~11 ~1 ~-5 ~11 ~1 ~5 minecraft:polished_blackstone_bricks
setblock ~-11 ~2 ~-5 minecraft:obsidian
setblock ~-11 ~2 ~-2 minecraft:obsidian
setblock ~-11 ~2 ~-1 minecraft:obsidian
setblock ~-11 ~2 ~1 minecraft:obsidian
setblock ~-11 ~2 ~2 minecraft:obsidian
setblock ~-11 ~2 ~5 minecraft:obsidian
setblock ~-10 ~2 ~-6 minecraft:obsidian
setblock ~-10 ~2 ~6 minecraft:obsidian
setblock ~-9 ~2 ~-7 minecraft:obsidian
setblock ~-9 ~2 ~7 minecraft:obsidian
setblock ~-8 ~2 ~-8 minecraft:obsidian
setblock ~-8 ~2 ~8 minecraft:obsidian
setblock ~-7 ~2 ~-9 minecraft:obsidian
setblock ~-7 ~2 ~9 minecraft:obsidian
setblock ~-6 ~2 ~-10 minecraft:obsidian
setblock ~-6 ~2 ~10 minecraft:obsidian
setblock ~-5 ~2 ~-11 minecraft:obsidian
setblock ~-5 ~2 ~11 minecraft:obsidian
setblock ~-2 ~2 ~-11 minecraft:obsidian
setblock ~-2 ~2 ~11 minecraft:obsidian
setblock ~-1 ~2 ~-11 minecraft:obsidian
setblock ~-1 ~2 ~11 minecraft:obsidian
setblock ~1 ~2 ~-11 minecraft:obsidian
setblock ~1 ~2 ~11 minecraft:obsidian
setblock ~2 ~2 ~-11 minecraft:obsidian
setblock ~2 ~2 ~11 minecraft:obsidian
setblock ~5 ~2 ~-11 minecraft:obsidian
setblock ~5 ~2 ~11 minecraft:obsidian
setblock ~6 ~2 ~-10 minecraft:obsidian
setblock ~6 ~2 ~10 minecraft:obsidian
setblock ~7 ~2 ~-9 minecraft:obsidian
setblock ~7 ~2 ~9 minecraft:obsidian
setblock ~8 ~2 ~-8 minecraft:obsidian
setblock ~8 ~2 ~8 minecraft:obsidian
setblock ~9 ~2 ~-7 minecraft:obsidian
setblock ~9 ~2 ~7 minecraft:obsidian
setblock ~10 ~2 ~-6 minecraft:obsidian
setblock ~10 ~2 ~6 minecraft:obsidian
setblock ~11 ~2 ~-5 minecraft:obsidian
setblock ~11 ~2 ~-2 minecraft:obsidian
setblock ~11 ~2 ~-1 minecraft:obsidian
setblock ~11 ~2 ~1 minecraft:obsidian
setblock ~11 ~2 ~2 minecraft:obsidian
setblock ~11 ~2 ~5 minecraft:obsidian
fill ~11 ~1 ~5 ~11 ~7 ~5 minecraft:obsidian
setblock ~11 ~8 ~5 minecraft:crying_obsidian
setblock ~11 ~9 ~5 minecraft:end_rod
fill ~11 ~1 ~-5 ~11 ~7 ~-5 minecraft:obsidian
setblock ~11 ~8 ~-5 minecraft:crying_obsidian
setblock ~11 ~9 ~-5 minecraft:end_rod
fill ~-11 ~1 ~5 ~-11 ~7 ~5 minecraft:obsidian
setblock ~-11 ~8 ~5 minecraft:crying_obsidian
setblock ~-11 ~9 ~5 minecraft:end_rod
fill ~-11 ~1 ~-5 ~-11 ~7 ~-5 minecraft:obsidian
setblock ~-11 ~8 ~-5 minecraft:crying_obsidian
setblock ~-11 ~9 ~-5 minecraft:end_rod
fill ~5 ~1 ~11 ~5 ~7 ~11 minecraft:obsidian
setblock ~5 ~8 ~11 minecraft:crying_obsidian
setblock ~5 ~9 ~11 minecraft:end_rod
fill ~5 ~1 ~-11 ~5 ~7 ~-11 minecraft:obsidian
setblock ~5 ~8 ~-11 minecraft:crying_obsidian
setblock ~5 ~9 ~-11 minecraft:end_rod
fill ~-5 ~1 ~11 ~-5 ~7 ~11 minecraft:obsidian
setblock ~-5 ~8 ~11 minecraft:crying_obsidian
setblock ~-5 ~9 ~11 minecraft:end_rod
fill ~-5 ~1 ~-11 ~-5 ~7 ~-11 minecraft:obsidian
setblock ~-5 ~8 ~-11 minecraft:crying_obsidian
setblock ~-5 ~9 ~-11 minecraft:end_rod
fill ~-1 ~1 ~-1 ~1 ~1 ~1 minecraft:chiseled_polished_blackstone
setblock ~0 ~2 ~0 minecraft:soul_campfire[lit=true]
