tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Вспышка угасла. Радиация в норме.", "color": "green"}]
