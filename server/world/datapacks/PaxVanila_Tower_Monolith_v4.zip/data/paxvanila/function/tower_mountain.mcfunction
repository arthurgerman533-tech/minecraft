scoreboard objectives add pxt dummy
execute if score #busy pxt matches 1 run return run tellraw @s {"text":"[Башня] Уже строится. Сброс: /function paxvanila:reset","color":"red"}
function paxvanila:probe_init
scoreboard players set #auto pxt 0
$scoreboard players set #g pxt $(ground)
$scoreboard players set #up pxt $(above)
scoreboard players set #busy pxt 1
tellraw @a [{"text":"[Башня] ","color":"gold"},{"text":"Меряю горы вокруг 0,0...","color":"yellow"}]
schedule function paxvanila:probe_start 2t replace
