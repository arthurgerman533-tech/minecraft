execute store result score #time pxw run random value 180..300
bossbar set paxweather:event name {"text": "❄ Метель", "color": "aqua"}
bossbar set paxweather:event color white
title @a times 10 50 20
title @a subtitle {"text": "Метель! Без крыши или кожаной брони замёрзнете.", "color": "gray"}
title @a title {"text": "❄ Метель", "color": "aqua", "bold": true}
tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Метель! Без крыши или кожаной брони замёрзнете.", "color": "aqua"}]
weather rain 600s
