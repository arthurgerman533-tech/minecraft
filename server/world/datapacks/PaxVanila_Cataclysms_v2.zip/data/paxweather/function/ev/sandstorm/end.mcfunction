tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Песок осел.", "color": "green"}]

kill @e[type=minecraft:husk,tag=pxw_mob,tag=pxw_sand]
