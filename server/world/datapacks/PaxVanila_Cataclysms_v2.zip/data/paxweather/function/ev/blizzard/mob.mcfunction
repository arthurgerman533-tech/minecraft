function paxweather:util/spot
execute at @e[type=minecraft:marker,tag=pxw_spot] run summon minecraft:stray ~ ~ ~ {Tags:["pxw_mob"],CustomName:{"text":"Ледяной странник","color":"aqua"}}
kill @e[type=minecraft:marker,tag=pxw_spot]
