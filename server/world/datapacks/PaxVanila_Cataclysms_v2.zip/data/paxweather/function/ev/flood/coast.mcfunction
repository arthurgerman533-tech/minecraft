particle minecraft:rain ~ ~4 ~ 7 2 7 0 120 normal @s
particle minecraft:splash ~ ~0.5 ~ 6 0.3 6 0 80 normal @s
execute if score #m4 pxw matches 0 run playsound minecraft:ambient.underwater.loop.additions.ultra_rare ambient @s ~ ~ ~ 0.8 0.6
execute if score #m10 pxw matches 0 run title @s actionbar {"text":"Волны выше бортов! На воде опасно.","color":"blue"}
