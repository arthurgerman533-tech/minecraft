scoreboard objectives add pxt dummy
execute in minecraft:overworld run forceload add 0 0
scoreboard players set #mx pxt -64
scoreboard players set #mn pxt 400
