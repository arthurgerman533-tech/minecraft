tag @a remove pxw_t
tag @a remove pxw_out
tag @a remove pxw_adult
tag @a remove pxw_hurt
execute store result score #now pxw run time query gametime
execute as @a unless score @s pxw_join = @s pxw_join store result score @s pxw_join run time query gametime
execute as @a run scoreboard players operation @s pxw_age = #now pxw
execute as @a run scoreboard players operation @s pxw_age -= @s pxw_join
execute as @a[gamemode=!spectator] at @s if dimension minecraft:overworld run tag @s add pxw_t
execute as @a[tag=pxw_t] at @s if predicate paxweather:sky run tag @s add pxw_out
execute as @a[tag=pxw_t,gamemode=!creative] if score @s pxw_age >= #newbie pxw run tag @s add pxw_adult
execute in minecraft:overworld run tag @a[tag=pxw_adult,x=-48,y=-64,z=-48,dx=96,dy=400,dz=96] remove pxw_adult
tag @a[tag=pxw_adult,scores={pxw_hp=10..}] add pxw_hurt
tag @a remove pxw_sp
tag @a remove pxw_moon
tag @a remove pxw_mars
tag @a remove pxw_sout
tag @a remove pxw_sadult
tag @a remove pxw_shurt
execute as @a[gamemode=!spectator] at @s if dimension paxweather:moon run tag @s add pxw_moon
execute as @a[gamemode=!spectator] at @s if dimension paxweather:mars run tag @s add pxw_mars
tag @a[tag=pxw_moon] add pxw_sp
tag @a[tag=pxw_mars] add pxw_sp
execute as @a[tag=pxw_sp] at @s if predicate paxweather:sky run tag @s add pxw_sout
execute as @a[tag=pxw_sp,gamemode=!creative] if score @s pxw_age >= #newbie pxw run tag @s add pxw_sadult
tag @a[tag=pxw_sadult,scores={pxw_hp=10..}] add pxw_shurt
function paxweather:util/gravity
