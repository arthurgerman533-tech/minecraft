advancement revoke @s only paxvanila:first_join
