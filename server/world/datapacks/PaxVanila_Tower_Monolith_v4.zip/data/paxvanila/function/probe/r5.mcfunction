execute in minecraft:overworld positioned 160 0 0 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 148 0 61 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 113 0 113 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 61 0 148 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 0 0 160 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -61 0 148 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -113 0 113 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -148 0 61 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -160 0 0 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -148 0 -61 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -113 0 -113 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -61 0 -148 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 0 0 -160 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 61 0 -148 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 113 0 -113 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 148 0 -61 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
schedule function paxvanila:probe/r6 4t replace
