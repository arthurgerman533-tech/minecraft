execute store result score #time pxw run random value 60..100
bossbar set paxweather:event name {"text": "▲ Лунотрясение", "color": "gray"}
bossbar set paxweather:event color white
title @a[tag=pxw_sp] times 10 50 20
title @a[tag=pxw_sp] subtitle {"text": "Лунотрясение! Луна гудит, как колокол.", "color": "gray"}
title @a[tag=pxw_sp] title {"text": "▲ Лунотрясение", "color": "gray", "bold": true}
tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Лунотрясение! Луна гудит, как колокол.", "color": "gray"}]
