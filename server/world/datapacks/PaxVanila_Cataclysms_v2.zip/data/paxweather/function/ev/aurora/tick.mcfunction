execute as @a[tag=pxw_out] at @s run particle minecraft:end_rod ~ ~28 ~ 24 2 24 0.005 30 normal @s
execute as @a[tag=pxw_out] at @s run particle minecraft:glow ~ ~24 ~ 24 3 24 0 40 normal @s
execute if score #m3 pxw matches 0 as @a[tag=pxw_out] at @s run particle minecraft:happy_villager ~ ~22 ~ 20 2 20 0 20 normal @s
execute if score #m20 pxw matches 0 run effect give @a[tag=pxw_out] minecraft:regeneration 5 0 true
execute if score #m20 pxw matches 0 run effect give @a[tag=pxw_out] minecraft:luck 30 0 true
execute if score #m10 pxw matches 0 as @a[tag=pxw_out] at @s run playsound minecraft:block.amethyst_block.chime ambient @s ~ ~10 ~ 1 0.8
