tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Мгла осела. Марс снова видно.", "color": "green"}]
