setblock ~-7 ~1 ~7 minecraft:lectern[facing=north,has_book=true]{Book:{id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Народ Глубин',author:'Учёные Ромеи',pages:['НАРОД ГЛУБИН\n(Безмолвные)\n~5000 д.Р.\n\nСамый старый народ мира. Они боялись неба и ушли под горы, в город из глубинного сланца.','Там они растили скалк, живую ткань, которая слышит каждый шаг. Однажды скалк вырастил себе тело. Это Хранитель.','За одну ночь Безмолвный город перестал быть городом. Говорят, Народ Глубин до сих пор там: стал частью скалка.','Что осталось: Древние города в Глубокой тьме.\n\nИх правило вырезают на дверях шахт:\n«Не буди то, что спит под тобой».']}}},Page:0}
setblock ~-7 ~2 ~7 minecraft:dark_oak_wall_sign[facing=north]{front_text:{messages:['НАРОД ГЛУБИН','Безмолвные','«Не буди то,','что спит»'],color:'dark_aqua',has_glowing_text:1b}}
setblock ~-6 ~1 ~7 minecraft:chiseled_deepslate
setblock ~-6 ~2 ~7 minecraft:candle[candles=3,lit=true]
setblock ~-9 ~1 ~0 minecraft:lectern[facing=east,has_book=true]{Book:{id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Ур-Кадим',author:'Учёные Ромеи',pages:['УР-КАДИМ\nЦарство Глиняных Городов\n~3500 д.Р.\n\nДве великие реки, ступенчатые храмы из глины. Здесь придумали письмо, счёт, колесо и деньги.','Царь Энмер-Кадим правил, по легенде, девятьсот лет и искал траву бессмертия.\n\nРеки ушли, поля стали пустыней, города засыпал песок.','Каждый черепок, который ты откапываешь кистью, это обрывок их табличек. Из черепков Ромея собирает «Летопись Предтеч».','Наследник: Карфагенская Торговая Держава. Её гири и мерки до сих пор зовут «кадимскими».']}}},Page:0}
setblock ~-9 ~2 ~0 minecraft:dark_oak_wall_sign[facing=east]{front_text:{messages:['УР-КАДИМ','Глиняные','города','→ Карфаген'],color:'gold',has_glowing_text:1b}}
setblock ~-9 ~1 ~1 minecraft:decorated_pot
setblock ~-7 ~1 ~-7 minecraft:lectern[facing=south,has_book=true]{Book:{id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Нэферу',author:'Учёные Ромеи',pages:['НЭФЕРУ\nДержава Солнца\n~3000 д.Р.\n\nНарод пустыни. Их цари, солнценосцы, строили пирамиды, чтобы после смерти подняться к свету.','Царица Сенкара Четвёртая велела вырезать своё лицо на всех пирамидах. Поэтому у храмов в пустыне один узор.','Нэферу первыми расплавили обсидиан и первыми открыли врата. Анх-Нэфер вошёл в Незер и вернулся с золотом.','Под пирамидами до сих пор лежит динамит.\n\nЗолото Нэферу кочует тысячу лет: скифы кладут его в курганы, Орда берёт его данью.']}}},Page:0}
setblock ~-7 ~2 ~-7 minecraft:dark_oak_wall_sign[facing=south]{front_text:{messages:['НЭФЕРУ','Держава Солнца','в песках','золото → степь'],color:'yellow',has_glowing_text:1b}}
setblock ~-6 ~1 ~-7 minecraft:chiseled_sandstone
setblock ~-6 ~2 ~-7 minecraft:gold_block
setblock ~0 ~1 ~-9 minecraft:lectern[facing=south,has_book=true]{Book:{id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Талассия',author:'Учёные Ромеи',pages:['ТАЛАССИЯ\nУтонувшая Империя\n~2600 д.Р.\n\nОстрова Западного моря. Флот ходил по всем водам, Морские Владыки строили дворцы-лабиринты.','Их храмы на дне стерегут стражи, одноглазые рыбы жрецов. Самые старые, Древние стражи, живут там до сих пор.','В Год Пепла под главным островом открылись врата. Остров взорвался, и Талассия ушла на дно за одну ночь.','Наследник: Эллинская Морская Лига. Эллины приносят дары морю перед каждым плаванием.\n\nЧертежи Талассии легли в «Аврору Пакс».']}}},Page:0}
setblock ~0 ~2 ~-9 minecraft:dark_oak_wall_sign[facing=south]{front_text:{messages:['ТАЛАССИЯ','Утонувшая','империя','→ Эллада'],color:'aqua',has_glowing_text:1b}}
setblock ~1 ~1 ~-9 minecraft:prismarine_bricks
setblock ~1 ~2 ~-9 minecraft:sea_lantern
setblock ~7 ~1 ~-7 minecraft:lectern[facing=south,has_book=true]{Book:{id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Медный Союз Каэр-Тала',author:'Учёные Ромеи',pages:['КАЭР-ТАЛА\nМедный Союз\n~2200 д.Р.\n\nГорные города, где правили мастера, а не цари. Медь, редстоун, двери, лампы, трубы.','Они строили залы испытаний, сделали вихрей в медной оболочке и железных големов-стражей.','Мастер Ойра Каэр-Тал предупреждала:\n«Каждые врата это дыра в стене нашего дома».\nЕё не послушали.','Каэр-Тала отдал на печать всю медь, всех големов и почти всех мастеров. Ойра из башни не вышла.\n\nНаследник: Дакийское Царство.']}}},Page:0}
setblock ~7 ~2 ~-7 minecraft:dark_oak_wall_sign[facing=south]{front_text:{messages:['КАЭР-ТАЛА','Медный Союз','строил башню','→ Дакия'],color:'gold',has_glowing_text:1b}}
setblock ~6 ~1 ~-7 minecraft:waxed_oxidized_cut_copper
setblock ~6 ~2 ~-7 minecraft:waxed_copper_bulb[lit=true]
setblock ~0 ~3 ~2 minecraft:crimson_wall_sign[facing=south]{front_text:{messages:['',{text:'P  A  X',color:'gold',bold:true},{text:'мир',color:'yellow'},''],color:'gold',has_glowing_text:1b}}
setblock ~-1 ~3 ~2 minecraft:crimson_wall_sign[facing=south]{front_text:{messages:['МЕДНАЯ','ПЕЧАТЬ','держит','Великие врата'],color:'white',has_glowing_text:1b}}
setblock ~1 ~3 ~2 minecraft:crimson_wall_sign[facing=south]{front_text:{messages:['СОРОК НОЧЕЙ','строили','три народа','~1150 д.Р.'],color:'white',has_glowing_text:1b}}
setblock ~-1 ~2 ~2 minecraft:crimson_wall_sign[facing=south]{front_text:{messages:['Глубины: (тишь)','Кадим: ПА-ШУ','Нэферу: ПАХ-РА',''],color:'white',has_glowing_text:1b}}
setblock ~0 ~2 ~2 minecraft:crimson_wall_sign[facing=south]{front_text:{messages:['на пяти','языках одно:','«мир куплен,','храни его»'],color:'yellow',has_glowing_text:1b}}
setblock ~1 ~2 ~2 minecraft:crimson_wall_sign[facing=south]{front_text:{messages:['Талассия:','ПАКСОС','Каэр-Тала:','ПАК-ТАЛ'],color:'white',has_glowing_text:1b}}
setblock ~0 ~1 ~2 minecraft:crimson_wall_sign[facing=south]{front_text:{messages:[{text:'шестая строка',color:'dark_gray'},{text:'xxxxxxxxxxx',color:'dark_purple',obfuscated:true},{text:'xxxxxxxx',color:'dark_purple',obfuscated:true},{text:'(её нет ни в одном языке)',color:'dark_gray'}],color:'dark_purple',has_glowing_text:1b}}
setblock ~-1 ~1 ~2 minecraft:crimson_wall_sign[facing=south]{front_text:{messages:['Проступила','сама, через','сто лет.','Ромул закрыл щитом'],color:'gray',has_glowing_text:0b}}
kill @e[type=minecraft:item_frame,tag=pxlore,distance=..40]
summon minecraft:item_frame ~1 ~1 ~2 {Facing:3b,Fixed:1b,Invulnerable:1b,Tags:["pxlore"],Item:{id:"minecraft:shield",count:1,components:{"minecraft:base_color":"red","minecraft:custom_name":{text:'Щит Ромула',color:'gold',italic:false},"minecraft:lore":[{text:'Закрывает шестую строку.',color:'gray',italic:true},{text:'Не снимай.',color:'gray',italic:true}]}}}
setblock ~-3 ~1 ~9 minecraft:chest[facing=north]{CustomName:'Кладовая Предтеч',Items:[{Slot:0b,id:"minecraft:bread",count:16,components:{"minecraft:custom_name":{text:'Хлеб для идущих следом',color:'yellow',italic:false},"minecraft:lore":[{text:'Испечён по рецепту Нэферу.',color:'gray',italic:true},{text:'Не черствеет тысячу лет (почти).',color:'gray',italic:true}]}},{Slot:1b,id:"minecraft:wheat_seeds",count:16,components:{"minecraft:custom_name":{text:'Семена двух рек',color:'yellow',italic:false},"minecraft:lore":[{text:'С полей Ур-Кадима.',color:'gray',italic:true}]}},{Slot:2b,id:"minecraft:torch",count:32},{Slot:3b,id:"minecraft:copper_ingot",count:16,components:{"minecraft:custom_name":{text:'Медь Каэр-Тала',color:'gold',italic:false},"minecraft:lore":[{text:'Последняя медь Союза.',color:'gray',italic:true},{text:'Остальная ушла на Печать.',color:'gray',italic:true}]}},{Slot:4b,id:"minecraft:brush",count:1,components:{"minecraft:custom_name":{text:'Кисть летописца',color:'aqua',italic:false},"minecraft:lore":[{text:'Копай подозрительный песок.',color:'gray',italic:true},{text:'Каждый черепок это строка Летописи.',color:'gray',italic:true}]}},{Slot:5b,id:"minecraft:map",count:2,components:{"minecraft:custom_name":{text:'Карта окрестностей',color:'yellow',italic:false},"minecraft:lore":[{text:'Отметь рудники и воду, как делали мы.',color:'gray',italic:true}]}},{Slot:6b,id:"minecraft:archer_pottery_sherd",count:1,components:{"minecraft:custom_name":{text:'Черепок Ур-Кадима',color:'gold',italic:false},"minecraft:lore":[{text:'Табличка о стрелках.',color:'gray',italic:true},{text:'Самая первая строка Летописи.',color:'gray',italic:true}]}},{Slot:7b,id:"minecraft:flint_and_steel",count:1,components:{"minecraft:custom_name":{text:'Огниво без врат',color:'red',italic:false},"minecraft:lore":[{text:'Для костра. Только для костра.',color:'gray',italic:true}]}}]}
setblock ~-3 ~2 ~9 minecraft:dark_oak_wall_sign[facing=north]{front_text:{messages:['МЫ НЕ УСПЕЛИ.','ПУСТЬ','УСПЕЕТЕ ВЫ.','— строители'],color:'gold',has_glowing_text:1b}}
setblock ~-4 ~1 ~9 minecraft:chest[facing=north]{CustomName:'Письма на пяти языках',Items:[{Slot:0b,id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Письмо из глубин',author:'Безмолвный',pages:['(переведено учёными Ромеи)\n\nНе шумите. Не копайте глубже, чем нужно. Если услышите стук сердца под землёй, уходите вверх.']}}},{Slot:1b,id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Табличка Ур-Кадима',author:'Писец Ур-Кадима',pages:['(переведено учёными Ромеи)\n\nДолг: сорок мер ячменя.\nДолжник: весь мир.\nСрок: когда погаснут врата.\n\nПечать писца.']}}},{Slot:2b,id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Свиток Нэферу',author:'Жрец Солнца',pages:['(переведено учёными Ромеи)\n\nМы рассчитали башню до высоты гор. Если её разберут ради обсидиана, всё начнётся снова. Поэтому снаружи она из простого камня.']}}},{Slot:3b,id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Морское письмо',author:'Моряк Талассии',pages:['(переведено учёными Ромеи)\n\nМы свезли сюда обсидиан со всех разбитых врат. Наш остров на дне. Если найдёте наши храмы, не будите стражей.']}}},{Slot:4b,id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Последнее письмо Ойры',author:'Ойра Каэр-Тал',pages:['(переведено учёными Ромеи)\n\nЯ иду в зал Печати. Механизм надо держать изнутри.\n\nСтражи, вот мой последний приказ: не пускайте зло ни наружу, ни внутрь.','Тому, кто придёт с миром: башня твоя. Береги её.\n\n— О. К.-Т.']}}}]}
setblock ~-5 ~1 ~9 minecraft:barrel[facing=up]
setblock ~-5 ~2 ~9 minecraft:lantern
setblock ~3 ~1 ~9 minecraft:barrel[facing=north]{CustomName:'Великая хроника Предтеч',Items:[{Slot:0b,id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Книга 0. Те, Кого Нет',author:'Учёные Ромеи',pages:['КНИГА НУЛЕВАЯ\nБезымянные\n??? д.Р.\n\nО них ничего не известно. Даже Предтечи не знали, кто они были.','Глубины звали их «Те, кто был до тишины». Кадим: «Пришедшие с неба». Нэферу: «Первое Солнце». Талассия: «Те, что под волной». Каэр-Тала: «Строители Рамок».','Остались только следы: крепости старше всех Предтеч, Рамка, которую нельзя сломать, глаза, что летят домой, странники и Край.','Друиды Галлии зовут их просто: «Те, Кого Нет».\n\nРомейские учёные пишут в летописи знак вопроса.\n\n?']}}},{Slot:1b,id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Книга 1. Век Тьмы',author:'Учёные Ромеи',pages:['КНИГА ПЕРВАЯ\nВек Тьмы под землёй\n6000–4200 д.Р.\n\nПервые люди жгли костры в пещерах и боялись неба.','Народ Глубин ушёл вниз и вырастил скалк. Около 4200 д.Р. проснулся Хранитель, и Безмолвный город замолк навсегда.']}}},{Slot:2b,id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Книга 2. Век Глины',author:'Учёные Ромеи',pages:['КНИГА ВТОРАЯ\nВек Глины\n3500–3000 д.Р.\n\nДве реки, глиняные города, первые таблички. Ур-Кадим считает зерно, долги и годы.','Энмер-Кадим ищет траву бессмертия. Говорят, это было морское сердце.\n\nК 3000 д.Р. наступает песок.']}}},{Slot:3b,id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Книга 3. Век Солнца',author:'Учёные Ромеи',pages:['КНИГА ТРЕТЬЯ\nВек Солнца\n3000–2400 д.Р.\n\nНэферу строят пирамиды. Мумии и стражи пустыни охраняют гробницы.','Последние жрецы уходят в джунгли и прячут храмы за рычагами и стрелами.']}}},{Slot:4b,id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Книга 4. Век Моря',author:'Учёные Ромеи',pages:['КНИГА ЧЕТВЁРТАЯ\nВек Моря\n2600–1800 д.Р.\n\nТалассия правит морем. Её корабли возят медь, зерно и золото всем Предтечам.','На дне растут храмы. Талассийцы дышат под водой с помощью раковин и морского сердца.']}}},{Slot:5b,id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Книга 5. Век Меди',author:'Учёные Ромеи',pages:['КНИГА ПЯТАЯ\nВек Меди\n2200–1200 д.Р.\n\nГорные города Каэр-Тала. Медь, редстоун, вихри, големы, залы испытаний.','Ойра Каэр-Тал, Первый Мастер, видит, куда ведут врата, и пишет:\n«Каждые врата это дыра в стене нашего дома».']}}},{Slot:6b,id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Книга 6. Век Врат',author:'Учёные Ромеи',pages:['КНИГА ШЕСТАЯ\nВек Врат\n1800–1200 д.Р.\n\nАнх-Нэфер открывает Незер. Двести лет Предтечи носят оттуда золото, кварц и светокамень.','Народы воюют за врата и через врата. Пиглины смотрят и запоминают.']}}},{Slot:7b,id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Книга 7. Год Пепла',author:'Учёные Ромеи',pages:['КНИГА СЕДЬМАЯ\nГод Пепла\n1200 д.Р.\n\nВесной врата открываются сами. Из них идут пиглины забирать своё золото.','Летом пал Ур-Кадим. Осенью взорвался остров Талассии. Зимой солнценосцы заперлись в пирамидах с динамитом.','Разрушенные порталы по всему миру остались с того года.']}}},{Slot:8b,id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Книга 8. Великая башня',author:'Учёные Ромеи',pages:['КНИГА ВОСЬМАЯ\nВеликая башня\n1200–1150 д.Р.\n\nКорни: Великие врата.\nЗал Печати: медь и редстоун, там Ойра.\nОснование: вход, кладовые.','Ствол: камень по чертежу пирамид.\nОбсидиановый пояс: обсидиан со всех врат.\nВершина: маяк Талассии.','Снаружи башня из простого камня. Обсидиан спрятан внутри, чтобы потомки не разобрали её на новые врата.']}}},{Slot:9b,id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Книга 9. Тёмные века',author:'Учёные Ромеи',pages:['КНИГА ДЕВЯТАЯ\nТёмные века\n1150–0 д.Р.\n\nЛюди забыли письмо, медь и корабли. Тысячу лет мир жил племенами.','Германцы и галлы жили в лесах и потому выжили. Степняки шли по руинам на конях. Башню звали «Домом мёртвых».']}}},{Slot:10b,id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Книга 10. Ромул',author:'Учёные Ромеи',pages:['КНИГА ДЕСЯТАЯ\nРомул\nгод 0\n\nСорок дней пути, как сорок ночей стройки. Ромул один пошёл к башне.','Големы шагнули навстречу. Ромул положил меч на землю:\n«Я пришёл с миром».\nСтражи отошли.','Год он учил знаки Предтеч и прочёл одно слово: PAX.\n\n«Мой народ будет хранить печать, пока стоит Ромея».']}}},{Slot:11b,id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Книга 11. Пророчество',author:'Учёные Ромеи',pages:['КНИГА ОДИННАДЦАТАЯ\nПророчество\n\nНа стене зала Печати Ойра оставила последнюю строку. Её знает только Ромул:','«Печать держится, пока народы помнят мир. Когда последний страж падёт и мир разделится в войне, печать треснет,','и врата откроются туда, куда не открывались никогда».\n\nНикто не знает, куда. Пока.']}}},{Slot:12b,id:"minecraft:writable_book",count:1,components:{"minecraft:custom_name":{text:'Чистая книга летописца',color:'white',italic:false},"minecraft:lore":[{text:'Допиши тринадцатую книгу.',color:'gray',italic:true},{text:'Её напишут игроки.',color:'gray',italic:true}]}}]}
setblock ~3 ~2 ~9 minecraft:dark_oak_wall_sign[facing=north]{front_text:{messages:['ВЕЛИКАЯ','ХРОНИКА','12 книг','— учёные Ромеи'],color:'gold',has_glowing_text:1b}}
setblock ~4 ~1 ~9 minecraft:chiseled_bookshelf[facing=north]
setblock ~4 ~2 ~9 minecraft:candle[candles=4,lit=true]
setblock ~-3 ~1 ~3 minecraft:lectern[facing=south,has_book=true]{Book:{id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Клятва Ромула',author:'Ромул',pages:['КЛЯТВА РОМУЛА\nгод 0\n\nЯ прочёл слово на камне. Это PAX, мир.\n\nМой народ будет хранить печать, пока стоит Ромея.','Мы не будем строить врата ради золота. Мы будем строить города ради мира.','Кто придёт к башне с миром, того стражи пропустят. Кто придёт со злом, того не пустят ни наружу, ни внутрь.\n\n— Ромул, основатель Священной Ромейской Республики']}}},Page:0}
setblock ~-4 ~1 ~3 minecraft:red_banner[rotation=8]{patterns:[{pattern:"minecraft:border",color:"yellow"},{pattern:"minecraft:rhombus",color:"yellow"},{pattern:"minecraft:circle",color:"red"}]}
setblock ~0 ~5 ~12 minecraft:crimson_wall_sign[facing=south]{front_text:{messages:['',{text:'P  A  X',color:'gold',bold:true},'',''],color:'gold',has_glowing_text:1b}}
setblock ~-2 ~3 ~12 minecraft:crimson_wall_sign[facing=south]{front_text:{messages:['МОНОЛИТ','печать над','Великими','вратами'],color:'white',has_glowing_text:1b}}
setblock ~2 ~3 ~12 minecraft:crimson_wall_sign[facing=south]{front_text:{messages:['Входи с миром.','Стражи башни','помнят приказ','Ойры К.-Т.'],color:'white',has_glowing_text:1b}}
fill ~-9 ~-15 ~-9 ~9 ~-5 ~9 minecraft:stone_bricks
fill ~-7 ~-14 ~-7 ~7 ~-6 ~7 minecraft:air
setblock ~-8 ~-15 ~-8 minecraft:mossy_stone_bricks
setblock ~-8 ~-5 ~-8 minecraft:mossy_stone_bricks
setblock ~-8 ~-5 ~-7 minecraft:cracked_stone_bricks
setblock ~-8 ~-5 ~-5 minecraft:cracked_stone_bricks
setblock ~-8 ~-5 ~1 minecraft:cracked_stone_bricks
setblock ~-8 ~-15 ~7 minecraft:cracked_stone_bricks
setblock ~-7 ~-5 ~-7 minecraft:cracked_stone_bricks
setblock ~-7 ~-15 ~-6 minecraft:mossy_stone_bricks
setblock ~-7 ~-15 ~-5 minecraft:cracked_stone_bricks
setblock ~-7 ~-15 ~-3 minecraft:mossy_stone_bricks
setblock ~-7 ~-15 ~3 minecraft:mossy_stone_bricks
setblock ~-7 ~-5 ~3 minecraft:cracked_stone_bricks
setblock ~-7 ~-15 ~5 minecraft:cracked_stone_bricks
setblock ~-6 ~-15 ~-8 minecraft:mossy_stone_bricks
setblock ~-6 ~-15 ~-7 minecraft:mossy_stone_bricks
setblock ~-6 ~-15 ~-6 minecraft:mossy_stone_bricks
setblock ~-6 ~-15 ~-5 minecraft:cracked_stone_bricks
setblock ~-6 ~-15 ~-4 minecraft:mossy_stone_bricks
setblock ~-6 ~-15 ~-2 minecraft:mossy_stone_bricks
setblock ~-6 ~-15 ~1 minecraft:mossy_stone_bricks
setblock ~-6 ~-15 ~5 minecraft:cracked_stone_bricks
setblock ~-6 ~-5 ~8 minecraft:mossy_stone_bricks
setblock ~-5 ~-5 ~-8 minecraft:mossy_stone_bricks
setblock ~-5 ~-15 ~-7 minecraft:cracked_stone_bricks
setblock ~-5 ~-5 ~-5 minecraft:cracked_stone_bricks
setblock ~-5 ~-15 ~-3 minecraft:mossy_stone_bricks
setblock ~-5 ~-5 ~-3 minecraft:cracked_stone_bricks
setblock ~-5 ~-5 ~-2 minecraft:cracked_stone_bricks
setblock ~-5 ~-5 ~2 minecraft:mossy_stone_bricks
setblock ~-5 ~-15 ~3 minecraft:cracked_stone_bricks
setblock ~-5 ~-15 ~4 minecraft:cracked_stone_bricks
setblock ~-5 ~-5 ~4 minecraft:cracked_stone_bricks
setblock ~-5 ~-15 ~5 minecraft:mossy_stone_bricks
setblock ~-5 ~-5 ~8 minecraft:mossy_stone_bricks
setblock ~-4 ~-15 ~-8 minecraft:cracked_stone_bricks
setblock ~-4 ~-15 ~-6 minecraft:mossy_stone_bricks
setblock ~-4 ~-15 ~-5 minecraft:mossy_stone_bricks
setblock ~-4 ~-5 ~-3 minecraft:mossy_stone_bricks
setblock ~-4 ~-15 ~0 minecraft:mossy_stone_bricks
setblock ~-4 ~-15 ~1 minecraft:mossy_stone_bricks
setblock ~-4 ~-15 ~2 minecraft:mossy_stone_bricks
setblock ~-4 ~-15 ~3 minecraft:cracked_stone_bricks
setblock ~-4 ~-15 ~5 minecraft:cracked_stone_bricks
setblock ~-4 ~-15 ~6 minecraft:mossy_stone_bricks
setblock ~-4 ~-5 ~6 minecraft:cracked_stone_bricks
setblock ~-3 ~-15 ~-3 minecraft:cracked_stone_bricks
setblock ~-3 ~-5 ~-3 minecraft:mossy_stone_bricks
setblock ~-3 ~-15 ~-1 minecraft:mossy_stone_bricks
setblock ~-3 ~-15 ~1 minecraft:mossy_stone_bricks
setblock ~-3 ~-15 ~5 minecraft:cracked_stone_bricks
setblock ~-3 ~-15 ~6 minecraft:mossy_stone_bricks
setblock ~-3 ~-15 ~8 minecraft:cracked_stone_bricks
setblock ~-2 ~-15 ~-8 minecraft:mossy_stone_bricks
setblock ~-2 ~-5 ~-7 minecraft:mossy_stone_bricks
setblock ~-2 ~-15 ~-6 minecraft:mossy_stone_bricks
setblock ~-2 ~-15 ~-5 minecraft:cracked_stone_bricks
setblock ~-2 ~-15 ~-4 minecraft:mossy_stone_bricks
setblock ~-2 ~-5 ~0 minecraft:mossy_stone_bricks
setblock ~-2 ~-15 ~3 minecraft:mossy_stone_bricks
setblock ~-2 ~-5 ~4 minecraft:mossy_stone_bricks
setblock ~-2 ~-15 ~5 minecraft:cracked_stone_bricks
setblock ~-2 ~-15 ~6 minecraft:mossy_stone_bricks
setblock ~-2 ~-5 ~6 minecraft:mossy_stone_bricks
setblock ~-2 ~-5 ~7 minecraft:cracked_stone_bricks
setblock ~-2 ~-15 ~8 minecraft:cracked_stone_bricks
setblock ~-2 ~-5 ~8 minecraft:mossy_stone_bricks
setblock ~-1 ~-15 ~-8 minecraft:cracked_stone_bricks
setblock ~-1 ~-5 ~-6 minecraft:cracked_stone_bricks
setblock ~-1 ~-15 ~-4 minecraft:mossy_stone_bricks
setblock ~-1 ~-15 ~-1 minecraft:mossy_stone_bricks
setblock ~-1 ~-15 ~0 minecraft:mossy_stone_bricks
setblock ~-1 ~-5 ~2 minecraft:cracked_stone_bricks
setblock ~-1 ~-15 ~3 minecraft:mossy_stone_bricks
setblock ~-1 ~-15 ~5 minecraft:mossy_stone_bricks
setblock ~-1 ~-15 ~8 minecraft:mossy_stone_bricks
setblock ~0 ~-15 ~-4 minecraft:cracked_stone_bricks
setblock ~0 ~-5 ~-4 minecraft:cracked_stone_bricks
setblock ~0 ~-15 ~-3 minecraft:mossy_stone_bricks
setblock ~0 ~-5 ~-3 minecraft:mossy_stone_bricks
setblock ~0 ~-15 ~-2 minecraft:cracked_stone_bricks
setblock ~0 ~-15 ~-1 minecraft:mossy_stone_bricks
setblock ~0 ~-15 ~0 minecraft:mossy_stone_bricks
setblock ~0 ~-5 ~0 minecraft:cracked_stone_bricks
setblock ~0 ~-15 ~2 minecraft:cracked_stone_bricks
setblock ~0 ~-15 ~5 minecraft:cracked_stone_bricks
setblock ~0 ~-5 ~6 minecraft:cracked_stone_bricks
setblock ~1 ~-15 ~-7 minecraft:mossy_stone_bricks
setblock ~1 ~-5 ~-7 minecraft:mossy_stone_bricks
setblock ~1 ~-5 ~-6 minecraft:mossy_stone_bricks
setblock ~1 ~-15 ~-3 minecraft:cracked_stone_bricks
setblock ~1 ~-15 ~-2 minecraft:mossy_stone_bricks
setblock ~1 ~-5 ~-2 minecraft:cracked_stone_bricks
setblock ~1 ~-15 ~-1 minecraft:cracked_stone_bricks
setblock ~1 ~-15 ~0 minecraft:mossy_stone_bricks
setblock ~1 ~-15 ~1 minecraft:cracked_stone_bricks
setblock ~1 ~-5 ~1 minecraft:cracked_stone_bricks
setblock ~1 ~-15 ~6 minecraft:cracked_stone_bricks
setblock ~1 ~-5 ~6 minecraft:mossy_stone_bricks
setblock ~2 ~-15 ~-8 minecraft:cracked_stone_bricks
setblock ~2 ~-5 ~-6 minecraft:cracked_stone_bricks
setblock ~2 ~-15 ~-4 minecraft:cracked_stone_bricks
setblock ~2 ~-15 ~-3 minecraft:mossy_stone_bricks
setblock ~2 ~-5 ~-2 minecraft:cracked_stone_bricks
setblock ~2 ~-15 ~0 minecraft:cracked_stone_bricks
setblock ~2 ~-5 ~2 minecraft:mossy_stone_bricks
setblock ~2 ~-15 ~3 minecraft:cracked_stone_bricks
setblock ~2 ~-5 ~5 minecraft:cracked_stone_bricks
setblock ~2 ~-5 ~7 minecraft:mossy_stone_bricks
setblock ~3 ~-5 ~-8 minecraft:mossy_stone_bricks
setblock ~3 ~-15 ~-6 minecraft:cracked_stone_bricks
setblock ~3 ~-15 ~-5 minecraft:cracked_stone_bricks
setblock ~3 ~-15 ~-4 minecraft:cracked_stone_bricks
setblock ~3 ~-15 ~-3 minecraft:mossy_stone_bricks
setblock ~3 ~-15 ~-2 minecraft:cracked_stone_bricks
setblock ~3 ~-5 ~-2 minecraft:mossy_stone_bricks
setblock ~3 ~-15 ~-1 minecraft:cracked_stone_bricks
setblock ~3 ~-15 ~0 minecraft:mossy_stone_bricks
setblock ~3 ~-15 ~1 minecraft:mossy_stone_bricks
setblock ~3 ~-15 ~2 minecraft:mossy_stone_bricks
setblock ~3 ~-15 ~3 minecraft:cracked_stone_bricks
setblock ~3 ~-5 ~3 minecraft:cracked_stone_bricks
setblock ~3 ~-5 ~4 minecraft:cracked_stone_bricks
setblock ~3 ~-15 ~6 minecraft:cracked_stone_bricks
setblock ~3 ~-5 ~8 minecraft:mossy_stone_bricks
setblock ~4 ~-5 ~-8 minecraft:mossy_stone_bricks
setblock ~4 ~-15 ~-7 minecraft:cracked_stone_bricks
setblock ~4 ~-5 ~-7 minecraft:mossy_stone_bricks
setblock ~4 ~-15 ~-6 minecraft:mossy_stone_bricks
setblock ~4 ~-15 ~-2 minecraft:mossy_stone_bricks
setblock ~4 ~-15 ~2 minecraft:mossy_stone_bricks
setblock ~4 ~-15 ~3 minecraft:cracked_stone_bricks
setblock ~4 ~-15 ~5 minecraft:mossy_stone_bricks
setblock ~4 ~-15 ~7 minecraft:mossy_stone_bricks
setblock ~4 ~-5 ~7 minecraft:mossy_stone_bricks
setblock ~5 ~-15 ~-8 minecraft:cracked_stone_bricks
setblock ~5 ~-5 ~-7 minecraft:cracked_stone_bricks
setblock ~5 ~-5 ~-4 minecraft:cracked_stone_bricks
setblock ~5 ~-5 ~-3 minecraft:mossy_stone_bricks
setblock ~5 ~-15 ~-1 minecraft:mossy_stone_bricks
setblock ~5 ~-15 ~0 minecraft:cracked_stone_bricks
setblock ~5 ~-15 ~2 minecraft:mossy_stone_bricks
setblock ~5 ~-5 ~2 minecraft:mossy_stone_bricks
setblock ~5 ~-15 ~3 minecraft:mossy_stone_bricks
setblock ~5 ~-15 ~4 minecraft:cracked_stone_bricks
setblock ~5 ~-15 ~6 minecraft:mossy_stone_bricks
setblock ~5 ~-5 ~6 minecraft:cracked_stone_bricks
setblock ~6 ~-5 ~-7 minecraft:cracked_stone_bricks
setblock ~6 ~-5 ~-6 minecraft:mossy_stone_bricks
setblock ~6 ~-15 ~-5 minecraft:cracked_stone_bricks
setblock ~6 ~-15 ~-4 minecraft:mossy_stone_bricks
setblock ~6 ~-5 ~-3 minecraft:cracked_stone_bricks
setblock ~6 ~-15 ~-2 minecraft:mossy_stone_bricks
setblock ~6 ~-15 ~-1 minecraft:cracked_stone_bricks
setblock ~6 ~-5 ~-1 minecraft:cracked_stone_bricks
setblock ~6 ~-15 ~1 minecraft:cracked_stone_bricks
setblock ~6 ~-5 ~6 minecraft:mossy_stone_bricks
setblock ~7 ~-15 ~-8 minecraft:mossy_stone_bricks
setblock ~7 ~-5 ~-8 minecraft:mossy_stone_bricks
setblock ~7 ~-15 ~-3 minecraft:mossy_stone_bricks
setblock ~7 ~-15 ~-1 minecraft:cracked_stone_bricks
setblock ~7 ~-15 ~3 minecraft:mossy_stone_bricks
setblock ~7 ~-15 ~5 minecraft:cracked_stone_bricks
setblock ~7 ~-5 ~6 minecraft:mossy_stone_bricks
setblock ~7 ~-15 ~7 minecraft:cracked_stone_bricks
setblock ~7 ~-5 ~7 minecraft:mossy_stone_bricks
setblock ~7 ~-5 ~8 minecraft:cracked_stone_bricks
setblock ~8 ~-15 ~-8 minecraft:cracked_stone_bricks
setblock ~8 ~-5 ~-5 minecraft:mossy_stone_bricks
setblock ~8 ~-15 ~-3 minecraft:cracked_stone_bricks
setblock ~8 ~-5 ~-3 minecraft:mossy_stone_bricks
setblock ~8 ~-15 ~-1 minecraft:mossy_stone_bricks
setblock ~8 ~-5 ~-1 minecraft:cracked_stone_bricks
setblock ~8 ~-15 ~3 minecraft:cracked_stone_bricks
setblock ~8 ~-15 ~5 minecraft:mossy_stone_bricks
setblock ~8 ~-5 ~5 minecraft:cracked_stone_bricks
setblock ~8 ~-5 ~7 minecraft:mossy_stone_bricks
setblock ~-8 ~-14 ~-8 minecraft:mossy_stone_bricks
setblock ~-7 ~-14 ~-8 minecraft:cracked_stone_bricks
setblock ~-7 ~-14 ~8 minecraft:cracked_stone_bricks
setblock ~-6 ~-14 ~-8 minecraft:cracked_stone_bricks
setblock ~-3 ~-14 ~8 minecraft:cracked_stone_bricks
setblock ~8 ~-14 ~-3 minecraft:mossy_stone_bricks
setblock ~-2 ~-14 ~-8 minecraft:cracked_stone_bricks
setblock ~-2 ~-14 ~8 minecraft:mossy_stone_bricks
setblock ~1 ~-14 ~-8 minecraft:mossy_stone_bricks
setblock ~-8 ~-14 ~1 minecraft:mossy_stone_bricks
setblock ~8 ~-14 ~1 minecraft:cracked_stone_bricks
setblock ~2 ~-14 ~8 minecraft:mossy_stone_bricks
setblock ~-8 ~-14 ~3 minecraft:mossy_stone_bricks
setblock ~8 ~-14 ~3 minecraft:mossy_stone_bricks
setblock ~-8 ~-14 ~4 minecraft:mossy_stone_bricks
setblock ~8 ~-14 ~4 minecraft:mossy_stone_bricks
setblock ~8 ~-14 ~5 minecraft:mossy_stone_bricks
setblock ~-8 ~-14 ~6 minecraft:cracked_stone_bricks
setblock ~8 ~-14 ~-8 minecraft:cracked_stone_bricks
setblock ~-8 ~-13 ~-8 minecraft:mossy_stone_bricks
setblock ~-6 ~-13 ~8 minecraft:cracked_stone_bricks
setblock ~-8 ~-13 ~-6 minecraft:mossy_stone_bricks
setblock ~-5 ~-13 ~8 minecraft:cracked_stone_bricks
setblock ~-8 ~-13 ~-4 minecraft:cracked_stone_bricks
setblock ~8 ~-13 ~-4 minecraft:mossy_stone_bricks
setblock ~8 ~-13 ~-3 minecraft:mossy_stone_bricks
setblock ~-8 ~-13 ~-2 minecraft:mossy_stone_bricks
setblock ~-1 ~-13 ~8 minecraft:cracked_stone_bricks
setblock ~-8 ~-13 ~-1 minecraft:mossy_stone_bricks
setblock ~0 ~-13 ~8 minecraft:cracked_stone_bricks
setblock ~-8 ~-13 ~0 minecraft:cracked_stone_bricks
setblock ~-8 ~-13 ~1 minecraft:cracked_stone_bricks
setblock ~3 ~-13 ~-8 minecraft:mossy_stone_bricks
setblock ~-8 ~-13 ~3 minecraft:cracked_stone_bricks
setblock ~5 ~-13 ~-8 minecraft:cracked_stone_bricks
setblock ~-8 ~-13 ~6 minecraft:mossy_stone_bricks
setblock ~-8 ~-13 ~7 minecraft:cracked_stone_bricks
setblock ~8 ~-13 ~-8 minecraft:mossy_stone_bricks
setblock ~-8 ~-12 ~-8 minecraft:cracked_stone_bricks
setblock ~8 ~-12 ~-8 minecraft:mossy_stone_bricks
setblock ~-7 ~-12 ~-8 minecraft:cracked_stone_bricks
setblock ~-7 ~-12 ~8 minecraft:mossy_stone_bricks
setblock ~-6 ~-12 ~-8 minecraft:cracked_stone_bricks
setblock ~-6 ~-12 ~8 minecraft:cracked_stone_bricks
setblock ~8 ~-12 ~-5 minecraft:cracked_stone_bricks
setblock ~-4 ~-12 ~-8 minecraft:mossy_stone_bricks
setblock ~-4 ~-12 ~8 minecraft:mossy_stone_bricks
setblock ~-2 ~-12 ~-8 minecraft:mossy_stone_bricks
setblock ~-8 ~-12 ~-2 minecraft:cracked_stone_bricks
setblock ~-1 ~-12 ~-8 minecraft:mossy_stone_bricks
setblock ~0 ~-12 ~-8 minecraft:mossy_stone_bricks
setblock ~-8 ~-12 ~0 minecraft:mossy_stone_bricks
setblock ~8 ~-12 ~0 minecraft:cracked_stone_bricks
setblock ~-8 ~-12 ~2 minecraft:mossy_stone_bricks
setblock ~-8 ~-12 ~3 minecraft:mossy_stone_bricks
setblock ~8 ~-12 ~3 minecraft:cracked_stone_bricks
setblock ~4 ~-12 ~8 minecraft:cracked_stone_bricks
setblock ~5 ~-12 ~-8 minecraft:cracked_stone_bricks
setblock ~-8 ~-12 ~7 minecraft:cracked_stone_bricks
setblock ~8 ~-12 ~-8 minecraft:cracked_stone_bricks
setblock ~-8 ~-12 ~8 minecraft:cracked_stone_bricks
setblock ~-8 ~-11 ~8 minecraft:mossy_stone_bricks
setblock ~8 ~-11 ~-7 minecraft:cracked_stone_bricks
setblock ~8 ~-11 ~-6 minecraft:cracked_stone_bricks
setblock ~-5 ~-11 ~8 minecraft:cracked_stone_bricks
setblock ~8 ~-11 ~-5 minecraft:cracked_stone_bricks
setblock ~-8 ~-11 ~-4 minecraft:mossy_stone_bricks
setblock ~8 ~-11 ~-4 minecraft:mossy_stone_bricks
setblock ~-1 ~-11 ~8 minecraft:mossy_stone_bricks
setblock ~0 ~-11 ~-8 minecraft:cracked_stone_bricks
setblock ~-8 ~-11 ~0 minecraft:mossy_stone_bricks
setblock ~8 ~-11 ~0 minecraft:mossy_stone_bricks
setblock ~-8 ~-11 ~1 minecraft:cracked_stone_bricks
setblock ~2 ~-11 ~-8 minecraft:cracked_stone_bricks
setblock ~-8 ~-11 ~2 minecraft:cracked_stone_bricks
setblock ~3 ~-11 ~-8 minecraft:cracked_stone_bricks
setblock ~3 ~-11 ~8 minecraft:mossy_stone_bricks
setblock ~8 ~-11 ~3 minecraft:mossy_stone_bricks
setblock ~4 ~-11 ~-8 minecraft:mossy_stone_bricks
setblock ~5 ~-11 ~8 minecraft:cracked_stone_bricks
setblock ~-8 ~-11 ~5 minecraft:mossy_stone_bricks
setblock ~8 ~-11 ~5 minecraft:cracked_stone_bricks
setblock ~-8 ~-11 ~6 minecraft:cracked_stone_bricks
setblock ~8 ~-11 ~6 minecraft:cracked_stone_bricks
setblock ~7 ~-11 ~8 minecraft:cracked_stone_bricks
setblock ~-8 ~-11 ~7 minecraft:mossy_stone_bricks
setblock ~8 ~-11 ~7 minecraft:cracked_stone_bricks
setblock ~8 ~-11 ~-8 minecraft:cracked_stone_bricks
setblock ~-8 ~-10 ~-8 minecraft:cracked_stone_bricks
setblock ~-7 ~-10 ~8 minecraft:mossy_stone_bricks
setblock ~8 ~-10 ~-7 minecraft:mossy_stone_bricks
setblock ~-6 ~-10 ~-8 minecraft:mossy_stone_bricks
setblock ~-6 ~-10 ~8 minecraft:mossy_stone_bricks
setblock ~8 ~-10 ~-6 minecraft:mossy_stone_bricks
setblock ~-4 ~-10 ~-8 minecraft:mossy_stone_bricks
setblock ~-4 ~-10 ~8 minecraft:mossy_stone_bricks
setblock ~-2 ~-10 ~-8 minecraft:cracked_stone_bricks
setblock ~8 ~-10 ~-2 minecraft:mossy_stone_bricks
setblock ~0 ~-10 ~-8 minecraft:cracked_stone_bricks
setblock ~0 ~-10 ~8 minecraft:cracked_stone_bricks
setblock ~1 ~-10 ~-8 minecraft:cracked_stone_bricks
setblock ~1 ~-10 ~8 minecraft:cracked_stone_bricks
setblock ~-8 ~-10 ~1 minecraft:mossy_stone_bricks
setblock ~8 ~-10 ~2 minecraft:cracked_stone_bricks
setblock ~3 ~-10 ~8 minecraft:cracked_stone_bricks
setblock ~4 ~-10 ~-8 minecraft:mossy_stone_bricks
setblock ~4 ~-10 ~8 minecraft:cracked_stone_bricks
setblock ~6 ~-10 ~8 minecraft:mossy_stone_bricks
setblock ~8 ~-10 ~6 minecraft:mossy_stone_bricks
setblock ~8 ~-10 ~8 minecraft:mossy_stone_bricks
setblock ~8 ~-9 ~-3 minecraft:cracked_stone_bricks
setblock ~-2 ~-9 ~8 minecraft:mossy_stone_bricks
setblock ~-8 ~-9 ~0 minecraft:cracked_stone_bricks
setblock ~2 ~-9 ~-8 minecraft:mossy_stone_bricks
setblock ~2 ~-9 ~8 minecraft:cracked_stone_bricks
setblock ~-8 ~-9 ~2 minecraft:cracked_stone_bricks
setblock ~3 ~-9 ~-8 minecraft:cracked_stone_bricks
setblock ~4 ~-9 ~8 minecraft:mossy_stone_bricks
setblock ~8 ~-9 ~4 minecraft:cracked_stone_bricks
setblock ~6 ~-9 ~-8 minecraft:mossy_stone_bricks
setblock ~6 ~-9 ~8 minecraft:mossy_stone_bricks
setblock ~-8 ~-9 ~6 minecraft:mossy_stone_bricks
setblock ~-8 ~-9 ~7 minecraft:mossy_stone_bricks
setblock ~8 ~-9 ~-8 minecraft:cracked_stone_bricks
setblock ~8 ~-9 ~8 minecraft:cracked_stone_bricks
setblock ~-8 ~-8 ~-8 minecraft:mossy_stone_bricks
setblock ~-7 ~-8 ~-8 minecraft:mossy_stone_bricks
setblock ~-4 ~-8 ~-8 minecraft:cracked_stone_bricks
setblock ~-3 ~-8 ~8 minecraft:mossy_stone_bricks
setblock ~8 ~-8 ~-3 minecraft:cracked_stone_bricks
setblock ~-2 ~-8 ~8 minecraft:cracked_stone_bricks
setblock ~-1 ~-8 ~-8 minecraft:cracked_stone_bricks
setblock ~0 ~-8 ~8 minecraft:cracked_stone_bricks
setblock ~1 ~-8 ~-8 minecraft:cracked_stone_bricks
setblock ~2 ~-8 ~8 minecraft:cracked_stone_bricks
setblock ~3 ~-8 ~8 minecraft:mossy_stone_bricks
setblock ~-8 ~-8 ~3 minecraft:cracked_stone_bricks
setblock ~8 ~-8 ~5 minecraft:cracked_stone_bricks
setblock ~-8 ~-8 ~7 minecraft:mossy_stone_bricks
setblock ~8 ~-8 ~7 minecraft:cracked_stone_bricks
setblock ~8 ~-8 ~8 minecraft:cracked_stone_bricks
setblock ~-8 ~-7 ~8 minecraft:cracked_stone_bricks
setblock ~8 ~-7 ~-7 minecraft:cracked_stone_bricks
setblock ~-6 ~-7 ~-8 minecraft:cracked_stone_bricks
setblock ~-8 ~-7 ~-6 minecraft:cracked_stone_bricks
setblock ~8 ~-7 ~-5 minecraft:cracked_stone_bricks
setblock ~-4 ~-7 ~-8 minecraft:mossy_stone_bricks
setblock ~8 ~-7 ~-4 minecraft:mossy_stone_bricks
setblock ~-2 ~-7 ~8 minecraft:cracked_stone_bricks
setblock ~-8 ~-7 ~-2 minecraft:mossy_stone_bricks
setblock ~8 ~-7 ~-2 minecraft:cracked_stone_bricks
setblock ~8 ~-7 ~0 minecraft:mossy_stone_bricks
setblock ~1 ~-7 ~-8 minecraft:mossy_stone_bricks
setblock ~-8 ~-7 ~1 minecraft:cracked_stone_bricks
setblock ~2 ~-7 ~-8 minecraft:mossy_stone_bricks
setblock ~2 ~-7 ~8 minecraft:cracked_stone_bricks
setblock ~3 ~-7 ~8 minecraft:cracked_stone_bricks
setblock ~8 ~-7 ~3 minecraft:mossy_stone_bricks
setblock ~6 ~-7 ~8 minecraft:mossy_stone_bricks
setblock ~-8 ~-7 ~7 minecraft:mossy_stone_bricks
setblock ~8 ~-7 ~7 minecraft:cracked_stone_bricks
setblock ~8 ~-7 ~-8 minecraft:cracked_stone_bricks
setblock ~8 ~-7 ~8 minecraft:cracked_stone_bricks
setblock ~8 ~-7 ~8 minecraft:cracked_stone_bricks
setblock ~-8 ~-6 ~-8 minecraft:cracked_stone_bricks
setblock ~-8 ~-6 ~8 minecraft:cracked_stone_bricks
setblock ~-8 ~-6 ~-8 minecraft:cracked_stone_bricks
setblock ~8 ~-6 ~-8 minecraft:mossy_stone_bricks
setblock ~-6 ~-6 ~8 minecraft:mossy_stone_bricks
setblock ~-8 ~-6 ~-5 minecraft:mossy_stone_bricks
setblock ~-4 ~-6 ~-8 minecraft:cracked_stone_bricks
setblock ~-4 ~-6 ~8 minecraft:cracked_stone_bricks
setblock ~-3 ~-6 ~-8 minecraft:cracked_stone_bricks
setblock ~-3 ~-6 ~8 minecraft:mossy_stone_bricks
setblock ~8 ~-6 ~-3 minecraft:cracked_stone_bricks
setblock ~-2 ~-6 ~8 minecraft:mossy_stone_bricks
setblock ~-1 ~-6 ~-8 minecraft:cracked_stone_bricks
setblock ~0 ~-6 ~-8 minecraft:mossy_stone_bricks
setblock ~0 ~-6 ~8 minecraft:mossy_stone_bricks
setblock ~-8 ~-6 ~0 minecraft:cracked_stone_bricks
setblock ~2 ~-6 ~8 minecraft:mossy_stone_bricks
setblock ~8 ~-6 ~3 minecraft:mossy_stone_bricks
setblock ~8 ~-6 ~4 minecraft:mossy_stone_bricks
setblock ~8 ~-6 ~5 minecraft:mossy_stone_bricks
setblock ~6 ~-6 ~-8 minecraft:mossy_stone_bricks
setblock ~6 ~-6 ~8 minecraft:cracked_stone_bricks
setblock ~-8 ~-6 ~8 minecraft:mossy_stone_bricks
fill ~-5 ~-14 ~-5 ~-5 ~-6 ~-5 minecraft:chiseled_stone_bricks
fill ~-5 ~-14 ~5 ~-5 ~-6 ~5 minecraft:chiseled_stone_bricks
fill ~5 ~-14 ~-5 ~5 ~-6 ~-5 minecraft:chiseled_stone_bricks
fill ~5 ~-14 ~5 ~5 ~-6 ~5 minecraft:chiseled_stone_bricks
fill ~-7 ~-14 ~-6 ~-7 ~-12 ~-6 minecraft:iron_bars
fill ~-7 ~-14 ~6 ~-7 ~-12 ~6 minecraft:iron_bars
fill ~-1 ~-15 ~-1 ~1 ~-15 ~1 minecraft:crying_obsidian
setblock ~-1 ~-14 ~-2 minecraft:end_portal_frame[facing=south,eye=false]
setblock ~0 ~-14 ~-2 minecraft:end_portal_frame[facing=south,eye=false]
setblock ~1 ~-14 ~-2 minecraft:end_portal_frame[facing=south,eye=false]
setblock ~-2 ~-14 ~-1 minecraft:end_portal_frame[facing=east,eye=false]
setblock ~-2 ~-14 ~0 minecraft:end_portal_frame[facing=east,eye=false]
setblock ~2 ~-14 ~0 minecraft:end_portal_frame[facing=west,eye=false]
setblock ~1 ~-14 ~2 minecraft:end_portal_frame[facing=north,eye=false]
setblock ~-2 ~-14 ~1 minecraft:cracked_stone_bricks
setblock ~2 ~-14 ~-1 minecraft:cracked_stone_bricks
setblock ~2 ~-14 ~1 minecraft:cracked_stone_bricks
setblock ~-1 ~-14 ~2 minecraft:cracked_stone_bricks
setblock ~0 ~-14 ~2 minecraft:cracked_stone_bricks
setblock ~-3 ~-15 ~-3 minecraft:obsidian
setblock ~-3 ~-15 ~-2 minecraft:obsidian
setblock ~-3 ~-15 ~-1 minecraft:obsidian
setblock ~-3 ~-15 ~0 minecraft:obsidian
setblock ~-3 ~-15 ~1 minecraft:obsidian
setblock ~-3 ~-15 ~2 minecraft:obsidian
setblock ~-3 ~-15 ~3 minecraft:obsidian
setblock ~3 ~-15 ~-3 minecraft:obsidian
setblock ~3 ~-15 ~-2 minecraft:obsidian
setblock ~3 ~-15 ~-1 minecraft:obsidian
setblock ~3 ~-15 ~0 minecraft:obsidian
setblock ~3 ~-15 ~1 minecraft:obsidian
setblock ~3 ~-15 ~2 minecraft:obsidian
setblock ~3 ~-15 ~3 minecraft:obsidian
setblock ~-2 ~-15 ~-3 minecraft:obsidian
setblock ~-1 ~-15 ~-3 minecraft:obsidian
setblock ~0 ~-15 ~-3 minecraft:obsidian
setblock ~1 ~-15 ~-3 minecraft:obsidian
setblock ~2 ~-15 ~-3 minecraft:obsidian
setblock ~-2 ~-15 ~3 minecraft:obsidian
setblock ~-1 ~-15 ~3 minecraft:obsidian
setblock ~0 ~-15 ~3 minecraft:obsidian
setblock ~1 ~-15 ~3 minecraft:obsidian
setblock ~2 ~-15 ~3 minecraft:obsidian
fill ~-3 ~-6 ~-7 ~-3 ~-6 ~7 minecraft:waxed_oxidized_copper_grate
fill ~3 ~-6 ~-7 ~3 ~-6 ~7 minecraft:waxed_oxidized_copper_grate
setblock ~-3 ~-7 ~-4 minecraft:waxed_copper_bulb[lit=true]
setblock ~-3 ~-7 ~0 minecraft:waxed_copper_bulb[lit=true]
setblock ~-3 ~-7 ~4 minecraft:waxed_copper_bulb[lit=true]
setblock ~3 ~-7 ~-4 minecraft:waxed_copper_bulb[lit=true]
setblock ~3 ~-7 ~0 minecraft:waxed_copper_bulb[lit=true]
setblock ~3 ~-7 ~4 minecraft:waxed_copper_bulb[lit=true]
setblock ~-6 ~-14 ~3 minecraft:soul_lantern
setblock ~6 ~-14 ~3 minecraft:soul_lantern
setblock ~-3 ~-14 ~6 minecraft:soul_lantern
setblock ~3 ~-14 ~-6 minecraft:soul_lantern
fill ~8 ~-14 ~-2 ~8 ~-11 ~2 minecraft:waxed_oxidized_chiseled_copper
fill ~8 ~-13 ~-1 ~8 ~-12 ~1 minecraft:waxed_oxidized_copper
setblock ~7 ~-12 ~0 minecraft:crimson_wall_sign[facing=west]{front_text:{messages:['ЗАЛ ПЕЧАТИ','не входить','здесь осталась','Ойра К.-Т.'],color:'gold',has_glowing_text:1b}}
setblock ~7 ~-13 ~-1 minecraft:waxed_copper_bulb[lit=true]
setblock ~7 ~-13 ~1 minecraft:waxed_copper_bulb[lit=true]
setblock ~-7 ~-12 ~-2 minecraft:dark_oak_wall_sign[facing=east]{front_text:{messages:[{text:'xxxxxxxx',color:'dark_purple',obfuscated:true},{text:'xxxxxx',color:'dark_purple',obfuscated:true},{text:'xxxxxxxxx',color:'dark_purple',obfuscated:true},''],color:'dark_purple',has_glowing_text:1b}}
setblock ~-7 ~-12 ~0 minecraft:dark_oak_wall_sign[facing=east]{front_text:{messages:[{text:'xxxxxxxx',color:'dark_purple',obfuscated:true},{text:'xxxxxx',color:'dark_purple',obfuscated:true},{text:'xxxxxxxxx',color:'dark_purple',obfuscated:true},''],color:'dark_purple',has_glowing_text:1b}}
setblock ~-7 ~-12 ~2 minecraft:dark_oak_wall_sign[facing=east]{front_text:{messages:[{text:'xxxxxxxx',color:'dark_purple',obfuscated:true},{text:'xxxxxx',color:'dark_purple',obfuscated:true},{text:'xxxxxxxxx',color:'dark_purple',obfuscated:true},''],color:'dark_purple',has_glowing_text:1b}}
setblock ~-7 ~-13 ~0 minecraft:dark_oak_wall_sign[facing=east]{front_text:{messages:['Эти знаки','старше всех','Предтеч.','Не читай вслух.'],color:'gray',has_glowing_text:0b}}
setblock ~0 ~-14 ~4 minecraft:lectern[facing=north,has_book=true]{Book:{id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Книга нулевая',author:'Учёные Ромеи',pages:['КНИГА НУЛЕВАЯ\nТе, Кого Нет\n\nВсё, что ниже, это следы, которые нельзя объяснить. Верить нельзя ни одной легенде.','Рамка из двенадцати плит. Её нельзя разбить и нельзя сделать. В плитах пустые гнёзда, как будто для глаз.','Здесь, под 0, 0, плит только семь. Остальные пять кто-то забрал. Или их никогда не было.','Куда они ушли?\n1. В Край.\n2. Ещё дальше.\n3. Стали странниками.\n4. Их съел Дракон.\n5. Никуда. Они здесь.','6. Их забрали врата, которые открылись «туда, куда не открывались никогда».\n\nРовно этими словами написано пророчество Ойры.']}}},Page:0}
setblock ~-6 ~-14 ~0 minecraft:lectern[facing=east,has_book=true]{Book:{id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Дневник раскопок',author:'Мастер-каменщик Каэр-Тала',pages:['ДНЕВНИК РАСКОПОК\nдень 3\n\nКопали фундамент под башню. На глубине нашли фундамент. Чужой. Каменный кирпич, как в крепостях под горами.','День 5.\n\nПосреди зала рамка. Семь плит. Кирка их не берёт. Порох их не берёт. Мастер Ойра долго молчала.','Ойра сказала:\n«Кто-то уже строил здесь башню. Может быть, по той же причине».\n\nМы строим поверх. Другого места нет.','День 40.\n\nПечать замкнута. Ойра внизу. Мы закрываем Корни и уходим наверх.\n\nКто прочтёт это: не ищи пять плит.']}}},Page:0}
setblock ~-6 ~-14 ~-2 minecraft:chest[facing=east]{CustomName:'Находки под фундаментом',Items:[{Slot:0b,id:"minecraft:stone_bricks",count:1,components:{"minecraft:custom_name":{text:'Кирпич старше Предтеч',color:'dark_purple',italic:false},"minecraft:lore":[{text:'Тот же, что в крепостях.',color:'gray',italic:true},{text:'Кто его клал, неизвестно.',color:'gray',italic:true}]}},{Slot:1b,id:"minecraft:ender_pearl",count:2,components:{"minecraft:custom_name":{text:'Жемчуг странника',color:'dark_purple',italic:false},"minecraft:lore":[{text:'Странники говорят задом наперёд.',color:'gray',italic:true}]}},{Slot:2b,id:"minecraft:blaze_powder",count:1,components:{"minecraft:custom_name":{text:'Огненная пыль Незера',color:'red',italic:false},"minecraft:lore":[{text:'С неё начался Век Врат.',color:'gray',italic:true}]}},{Slot:3b,id:"minecraft:copper_ingot",count:4,components:{"minecraft:custom_name":{text:'Обломок Медной Печати',color:'gold',italic:false},"minecraft:lore":[{text:'Тёплый. Медь не бывает тёплой.',color:'gray',italic:true}]}},{Slot:4b,id:"minecraft:candle",count:3,components:{"minecraft:custom_name":{text:'Свечи Ойры',color:'yellow',italic:false},"minecraft:lore":[{text:'Горели сорок ночей.',color:'gray',italic:true}]}},{Slot:5b,id:"minecraft:written_book",count:1,components:{"minecraft:written_book_content":{title:'Зарисовка Рамки',author:'Мастер-каменщик',pages:['Семь плит. Пять гнёзд пусты всегда, сколько ни смотри.\n\n(на полях нарисован глаз)']}}}]}
fill ~-6 ~-1 ~-4 ~-4 ~-5 ~-2 minecraft:stone_bricks
fill ~-5 ~-1 ~-3 ~-5 ~-5 ~-3 minecraft:air
fill ~-6 ~-14 ~-3 ~-6 ~-6 ~-3 minecraft:stone_bricks
fill ~-5 ~-14 ~-3 ~-5 ~-1 ~-3 minecraft:ladder[facing=east]
setblock ~-5 ~0 ~-3 minecraft:waxed_copper_trapdoor[facing=east,half=top,open=false]
setblock ~-6 ~1 ~-2 minecraft:dark_oak_sign[rotation=4]{front_text:{messages:['КОРНИ','спуск вниз','чужой фундамент','иди тихо'],color:'gray',has_glowing_text:0b}}
