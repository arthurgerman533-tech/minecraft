function paxweather:util/grav_off
attribute @s minecraft:gravity modifier add paxweather:low_gravity -0.05 add_value
attribute @s minecraft:fall_damage_multiplier modifier add paxweather:low_gravity -0.6 add_multiplied_total
attribute @s minecraft:safe_fall_distance modifier add paxweather:low_gravity 4 add_value
tag @s add pxw_gmars
title @s actionbar {"text":"Марс: гравитация 3/8.","color":"red"}
