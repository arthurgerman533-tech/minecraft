execute if score #done pxt matches 1 run return 0
execute if score #y pxt >= #t pxt run return run scoreboard players set #done pxt 1
scoreboard players set #24 pxt 24
scoreboard players set #16 pxt 16
scoreboard players set #12 pxt 12
scoreboard players set #8 pxt 8
scoreboard players operation #i pxt = #y pxt
scoreboard players operation #i pxt -= #g pxt
scoreboard players remove #i pxt 1
scoreboard players operation #k pxt = #i pxt
scoreboard players operation #k pxt %= #24 pxt
scoreboard players operation #b pxt = #i pxt
scoreboard players operation #b pxt %= #16 pxt
scoreboard players operation #s pxt = #i pxt
scoreboard players operation #s pxt %= #12 pxt
scoreboard players operation #l pxt = #i pxt
scoreboard players operation #l pxt %= #8 pxt
scoreboard players operation #t8 pxt = #t pxt
scoreboard players remove #t8 pxt 8
execute store result storage paxvanila:t a.k int 1 run scoreboard players get #k pxt
execute store result storage paxvanila:t a.y int 1 run scoreboard players get #y pxt
function paxvanila:layer with storage paxvanila:t a
execute if score #i pxt matches 2.. run function paxvanila:ov {f:"clear_ring"}
execute if score #i pxt matches 4.. if score #y pxt < #t8 pxt if score #b pxt matches 14 run function paxvanila:ov {f:"band_a"}
execute if score #i pxt matches 4.. if score #y pxt < #t8 pxt if score #b pxt matches 15 run function paxvanila:ov {f:"band_b"}
execute if score #i pxt matches 4.. if score #y pxt < #t8 pxt if score #b pxt matches 0 run function paxvanila:ov {f:"band_c"}
execute if score #i pxt matches 8.. if score #y pxt < #t8 pxt if score #s pxt matches 4..7 run function paxvanila:ov {f:"slit"}
execute if score #l pxt matches 4 run function paxvanila:ov {f:"light"}
scoreboard players add #y pxt 1
