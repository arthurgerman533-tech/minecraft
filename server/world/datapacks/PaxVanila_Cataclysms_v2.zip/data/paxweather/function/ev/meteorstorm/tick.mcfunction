execute as @a[tag=pxw_sout] at @s run particle minecraft:end_rod ~ ~30 ~ 20 4 20 0.02 10 normal @s
execute if score #m2 pxw matches 0 as @a[tag=pxw_sout,sort=random,limit=2] at @s run function paxweather:ev/meteor/spawn
