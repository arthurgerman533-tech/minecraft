execute store result score #time pxw run random value 240..360
bossbar set paxweather:event name {"text": "⚡ Гроза", "color": "yellow"}
bossbar set paxweather:event color yellow
title @a times 10 50 20
title @a subtitle {"text": "Гроза над PaxVanila! Молнии бьют по высоким местам.", "color": "gray"}
title @a title {"text": "⚡ Гроза", "color": "yellow", "bold": true}
tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Гроза над PaxVanila! Молнии бьют по высоким местам.", "color": "yellow"}]
weather thunder 600s
