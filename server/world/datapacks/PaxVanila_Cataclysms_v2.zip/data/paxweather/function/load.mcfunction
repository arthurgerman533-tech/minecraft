scoreboard objectives add pxw dummy
scoreboard objectives add pxw_hp health
scoreboard objectives add pxw_join dummy
scoreboard objectives add pxw_age dummy
scoreboard objectives add pxw_mt dummy
execute unless score #init pxw matches 1 run function paxweather:setup
scoreboard players set #2 pxw 2
scoreboard players set #3 pxw 3
scoreboard players set #4 pxw 4
scoreboard players set #5 pxw 5
scoreboard players set #6 pxw 6
scoreboard players set #8 pxw 8
scoreboard players set #10 pxw 10
scoreboard players set #12 pxw 12
scoreboard players set #15 pxw 15
scoreboard players set #20 pxw 20
scoreboard players set #30 pxw 30
scoreboard players set #60 pxw 60
bossbar add paxweather:event {"text":"Погода"}
schedule function paxweather:second 1s replace
