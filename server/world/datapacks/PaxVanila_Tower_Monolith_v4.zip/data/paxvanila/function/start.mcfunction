scoreboard players operation #min pxt = #g pxt
scoreboard players add #min pxt 64
execute if score #t pxt < #min pxt run scoreboard players operation #t pxt = #min pxt
execute if score #t pxt matches 311.. run scoreboard players set #t pxt 310
execute if score #t pxt <= #g pxt run return run tellraw @s {"text":"[Башня] Земля слишком высоко.","color":"red"}
scoreboard players set #busy pxt 1
scoreboard players operation #hh pxt = #t pxt
scoreboard players operation #hh pxt -= #g pxt
execute in minecraft:overworld run forceload add -32 -32 31 31
tellraw @a [{"text":"[Башня] ","color":"gold"},{"text":"Строю монолит: земля Y=","color":"yellow"},{"score":{"name":"#g","objective":"pxt"}},{"text":", верх Y="},{"score":{"name":"#t","objective":"pxt"}},{"text":" (высота "},{"score":{"name":"#hh","objective":"pxt"}},{"text":" блоков)"}]
schedule function paxvanila:phase1 20t replace
