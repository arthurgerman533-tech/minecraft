function paxvanila:probe_read
scoreboard players operation #sum pxt += #p pxt
