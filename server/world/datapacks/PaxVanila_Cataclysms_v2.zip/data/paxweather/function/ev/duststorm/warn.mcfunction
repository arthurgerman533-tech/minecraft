tellraw @a [{"text": "≈ ", "color": "red"}, {"text": "Пылевая буря Марса. ", "color": "red", "bold": true}, {"text": "Над Марсом поднимается красная мгла. Через минуту пылевая буря.", "color": "gray"}]
execute as @a[tag=pxw_sp] at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 0.6 0.6
