execute as @a[tag=pxw_out] at @s run particle minecraft:rain ~ ~4 ~ 6 2 6 0 60 normal @s
execute if score #m4 pxw matches 0 as @a[tag=pxw_out] at @s run particle minecraft:electric_spark ~ ~1 ~ 3 2 3 0.1 25 normal @s
execute if score #m6 pxw matches 0 as @a[tag=pxw_out] at @s run playsound minecraft:entity.lightning_bolt.thunder weather @s ~ ~ ~ 0.5 0.7
execute if score #m10 pxw matches 0 as @a[tag=pxw_out,y=110,dy=300] at @s run function paxweather:ev/storm/high
