tellraw @a [{"text": "▲ ", "color": "red"}, {"text": "Землетрясение. ", "color": "red", "bold": true}, {"text": "Звери замолкли, вода в колодцах дрожит. Через минуту землетрясение: выходите из шахт!", "color": "gray"}]
execute as @a at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 0.6 0.6
