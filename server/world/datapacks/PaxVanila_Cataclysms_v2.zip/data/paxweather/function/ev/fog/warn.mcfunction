tellraw @a [{"text": "? ", "color": "gray"}, {"text": "Туман Безымянных. ", "color": "gray", "bold": true}, {"text": "С низин ползёт белый туман. Говорят, в нём ходят Те, Кого Нет.", "color": "gray"}]
execute as @a at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 0.6 0.6
