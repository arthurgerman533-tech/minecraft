execute if score #event pxw matches 1.. run function paxweather:core/end
scoreboard players set #pending pxw 12
scoreboard players set #warn pxw 11
function paxweather:ev/meteorstorm/warn
tellraw @s [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Запущено: Метеоритный шторм (через 10 сек).", "color": "green"}]
