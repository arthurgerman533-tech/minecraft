tellraw @a [{"text": "▲ ", "color": "gray"}, {"text": "Лунотрясение. ", "color": "gray", "bold": true}, {"text": "Сейсмографы Селены пищат. Через минуту лунотрясение.", "color": "gray"}]
execute as @a[tag=pxw_sp] at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 0.6 0.6
