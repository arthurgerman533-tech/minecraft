scoreboard players set #sum pxt 0
execute in minecraft:overworld positioned 24 0 0 positioned over motion_blocking_no_leaves run function paxvanila:probe_sum
execute in minecraft:overworld positioned 17 0 17 positioned over motion_blocking_no_leaves run function paxvanila:probe_sum
execute in minecraft:overworld positioned 0 0 24 positioned over motion_blocking_no_leaves run function paxvanila:probe_sum
execute in minecraft:overworld positioned -17 0 17 positioned over motion_blocking_no_leaves run function paxvanila:probe_sum
execute in minecraft:overworld positioned -24 0 0 positioned over motion_blocking_no_leaves run function paxvanila:probe_sum
execute in minecraft:overworld positioned -17 0 -17 positioned over motion_blocking_no_leaves run function paxvanila:probe_sum
execute in minecraft:overworld positioned 0 0 -24 positioned over motion_blocking_no_leaves run function paxvanila:probe_sum
execute in minecraft:overworld positioned 17 0 -17 positioned over motion_blocking_no_leaves run function paxvanila:probe_sum
scoreboard players set #8 pxt 8
scoreboard players operation #g pxt = #sum pxt
scoreboard players operation #g pxt /= #8 pxt
scoreboard players remove #g pxt 1
