setblock ~7 ~0 ~8 minecraft:sea_lantern
setblock ~-8 ~0 ~7 minecraft:sea_lantern
setblock ~-7 ~0 ~-8 minecraft:sea_lantern
setblock ~8 ~0 ~-7 minecraft:sea_lantern
