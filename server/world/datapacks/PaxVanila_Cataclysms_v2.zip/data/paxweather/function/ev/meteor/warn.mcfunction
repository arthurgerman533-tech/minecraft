tellraw @a [{"text": "☄ ", "color": "light_purple"}, {"text": "Звёздный дождь. ", "color": "light_purple", "bold": true}, {"text": "Сеть Страж-7: вижу огни над облаками. Через минуту звёздный дождь.", "color": "gray"}]
execute as @a at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 0.6 0.6
