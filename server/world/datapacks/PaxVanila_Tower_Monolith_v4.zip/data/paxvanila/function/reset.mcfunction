scoreboard players set #busy pxt 0
schedule clear paxvanila:loop
schedule clear paxvanila:phase1
schedule clear paxvanila:probe_done
schedule clear paxvanila:probe_start
schedule clear paxvanila:probe/r0
schedule clear paxvanila:probe/r1
schedule clear paxvanila:probe/r2
schedule clear paxvanila:probe/r3
schedule clear paxvanila:probe/r4
schedule clear paxvanila:probe/r5
schedule clear paxvanila:probe/r6
schedule clear paxvanila:probe/r7
kill @e[type=minecraft:marker,tag=pxprobe]
execute in minecraft:overworld run forceload remove -32 -32 31 31
tellraw @s {"text":"[Башня] Сброшено.","color":"gray"}
