execute as @a[tag=pxw_t] at @s run particle minecraft:white_ash ~ ~1 ~ 6 1.5 6 0 120 normal @s
execute as @a[tag=pxw_t] at @s run particle minecraft:campfire_cosmic_smoke ~ ~0.3 ~ 8 0.2 8 0.002 10 normal @s
execute if score #m8 pxw matches 0 run function paxweather:ev/fog/whisper
