execute store result score #time pxw run random value 180..300
bossbar set paxweather:event name {"text": "? Туман Безымянных", "color": "gray"}
bossbar set paxweather:event color white
title @a times 10 50 20
title @a subtitle {"text": "Туман Безымянных. Кто-то шепчет в тумане.", "color": "gray"}
title @a title {"text": "? Туман Безымянных", "color": "gray", "bold": true}
tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Туман Безымянных. Кто-то шепчет в тумане.", "color": "gray"}]
