tellraw @a [{"text": "☠ ", "color": "dark_red"}, {"text": "Пепельная ночь. ", "color": "dark_red", "bold": true}, {"text": "Монолит гудит. Пахнет серой, как в Год Пепла. Через минуту пепельная ночь.", "color": "gray"}]
execute as @a at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 0.6 0.6
