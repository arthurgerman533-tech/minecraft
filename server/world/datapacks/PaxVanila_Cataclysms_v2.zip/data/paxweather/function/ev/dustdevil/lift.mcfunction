particle minecraft:falling_dust{block_state:{Name:"minecraft:red_sand"}} ~ ~3 ~ 0.7 3 0.7 0 200 force
particle minecraft:cloud ~ ~0.5 ~ 1 0.3 1 0.05 30 force
playsound minecraft:entity.breeze.wind_burst ambient @a[distance=..32] ~ ~ ~ 1 0.6
effect give @s minecraft:slow_falling 7 0 true
effect give @s minecraft:levitation 1 6 true
title @s actionbar {"text":"Вихрь подхватил тебя!","color":"gold"}
