scoreboard players remove #time pxw 1
execute store result bossbar paxweather:event value run scoreboard players get #time pxw
function paxweather:core/bar_players
scoreboard players operation #m2 pxw = #time pxw
scoreboard players operation #m2 pxw %= #2 pxw
scoreboard players operation #m3 pxw = #time pxw
scoreboard players operation #m3 pxw %= #3 pxw
scoreboard players operation #m4 pxw = #time pxw
scoreboard players operation #m4 pxw %= #4 pxw
scoreboard players operation #m5 pxw = #time pxw
scoreboard players operation #m5 pxw %= #5 pxw
scoreboard players operation #m6 pxw = #time pxw
scoreboard players operation #m6 pxw %= #6 pxw
scoreboard players operation #m8 pxw = #time pxw
scoreboard players operation #m8 pxw %= #8 pxw
scoreboard players operation #m10 pxw = #time pxw
scoreboard players operation #m10 pxw %= #10 pxw
scoreboard players operation #m12 pxw = #time pxw
scoreboard players operation #m12 pxw %= #12 pxw
scoreboard players operation #m15 pxw = #time pxw
scoreboard players operation #m15 pxw %= #15 pxw
scoreboard players operation #m20 pxw = #time pxw
scoreboard players operation #m20 pxw %= #20 pxw
scoreboard players operation #m30 pxw = #time pxw
scoreboard players operation #m30 pxw %= #30 pxw
execute if score #event pxw matches 1 run function paxweather:ev/storm/tick
execute if score #event pxw matches 2 run function paxweather:ev/blizzard/tick
execute if score #event pxw matches 3 run function paxweather:ev/drought/tick
execute if score #event pxw matches 4 run function paxweather:ev/sandstorm/tick
execute if score #event pxw matches 5 run function paxweather:ev/quake/tick
execute if score #event pxw matches 6 run function paxweather:ev/meteor/tick
execute if score #event pxw matches 7 run function paxweather:ev/ash/tick
execute if score #event pxw matches 8 run function paxweather:ev/flood/tick
execute if score #event pxw matches 9 run function paxweather:ev/fog/tick
execute if score #event pxw matches 10 run function paxweather:ev/aurora/tick
execute if score #event pxw matches 11 run function paxweather:ev/flare/tick
execute if score #event pxw matches 12 run function paxweather:ev/meteorstorm/tick
execute if score #event pxw matches 13 run function paxweather:ev/duststorm/tick
execute if score #event pxw matches 14 run function paxweather:ev/dustdevil/tick
execute if score #event pxw matches 15 run function paxweather:ev/moonquake/tick
execute if score #event pxw matches 16 run function paxweather:ev/lunarnight/tick
execute if score #event pxw matches 17 run function paxweather:ev/magstorm/tick
execute if score #event pxw matches 18 run function paxweather:ev/comet/tick
execute if score #time pxw matches ..0 run function paxweather:core/end
