execute store result score #r pxw run random value 1..6
execute if score #r pxw matches 1 run title @a[tag=pxw_sp] actionbar {"text": "СТРАЖ-7 >> 01010000 01000001 01011000", "color": "dark_aqua"}
execute if score #r pxw matches 2 run title @a[tag=pxw_sp] actionbar {"text": "СТРАЖ-7 >> с-с-связь... потеряна...", "color": "dark_aqua"}
execute if score #r pxw matches 3 run title @a[tag=pxw_sp] actionbar {"text": "СТРАЖ-7 >> я в-вижу вас... не вижу вас...", "color": "dark_aqua"}
execute if score #r pxw matches 4 run title @a[tag=pxw_sp] actionbar {"text": "СТРАЖ-7 >> PAX PAX PAX PAX PAX", "color": "dark_aqua"}
execute if score #r pxw matches 5 run title @a[tag=pxw_sp] actionbar {"text": "СТРАЖ-7 >> компасы врут. Не верь стрелке.", "color": "dark_aqua"}
execute if score #r pxw matches 6 run title @a[tag=pxw_sp] actionbar {"text": "СТРАЖ-7 >> запомните... свои... имена...", "color": "dark_aqua"}
execute as @a[tag=pxw_sp] at @s run playsound minecraft:block.beacon.deactivate ambient @s ~ ~ ~ 0.5 1.6
