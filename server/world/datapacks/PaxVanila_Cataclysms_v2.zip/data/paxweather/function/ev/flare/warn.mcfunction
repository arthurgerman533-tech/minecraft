tellraw @a [{"text": "☼ ", "color": "yellow"}, {"text": "Солнечная вспышка. ", "color": "yellow", "bold": true}, {"text": "Сеть Страж-7: на Солнце вспышка. Через минуту радиация: колонистам в укрытия!", "color": "gray"}]
execute as @a[tag=pxw_sp] at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 0.6 0.6
