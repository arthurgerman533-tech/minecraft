$execute in minecraft:overworld positioned 0 $(y) 0 run function paxmono:shell
$execute in minecraft:overworld positioned 0 $(y) 0 run function paxmono:stair/s$(k)
