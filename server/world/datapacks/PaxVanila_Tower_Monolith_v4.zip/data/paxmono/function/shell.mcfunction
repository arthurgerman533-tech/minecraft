fill ~-11 ~0 ~-5 ~-11 ~0 ~5 minecraft:obsidian
fill ~-10 ~0 ~-6 ~-10 ~0 ~6 minecraft:obsidian
fill ~-9 ~0 ~-7 ~-9 ~0 ~7 minecraft:obsidian
fill ~-8 ~0 ~-8 ~-8 ~0 ~8 minecraft:obsidian
fill ~-7 ~0 ~-9 ~-7 ~0 ~9 minecraft:obsidian
fill ~-6 ~0 ~-10 ~-6 ~0 ~10 minecraft:obsidian
fill ~-5 ~0 ~-11 ~-5 ~0 ~11 minecraft:obsidian
fill ~-4 ~0 ~-11 ~-4 ~0 ~11 minecraft:obsidian
fill ~-3 ~0 ~-11 ~-3 ~0 ~11 minecraft:obsidian
fill ~-2 ~0 ~-11 ~-2 ~0 ~11 minecraft:obsidian
fill ~-1 ~0 ~-11 ~-1 ~0 ~11 minecraft:obsidian
fill ~0 ~0 ~-11 ~0 ~0 ~11 minecraft:obsidian
fill ~1 ~0 ~-11 ~1 ~0 ~11 minecraft:obsidian
fill ~2 ~0 ~-11 ~2 ~0 ~11 minecraft:obsidian
fill ~3 ~0 ~-11 ~3 ~0 ~11 minecraft:obsidian
fill ~4 ~0 ~-11 ~4 ~0 ~11 minecraft:obsidian
fill ~5 ~0 ~-11 ~5 ~0 ~11 minecraft:obsidian
fill ~6 ~0 ~-10 ~6 ~0 ~10 minecraft:obsidian
fill ~7 ~0 ~-9 ~7 ~0 ~9 minecraft:obsidian
fill ~8 ~0 ~-8 ~8 ~0 ~8 minecraft:obsidian
fill ~9 ~0 ~-7 ~9 ~0 ~7 minecraft:obsidian
fill ~10 ~0 ~-6 ~10 ~0 ~6 minecraft:obsidian
fill ~11 ~0 ~-5 ~11 ~0 ~5 minecraft:obsidian
fill ~-10 ~0 ~-5 ~-10 ~0 ~5 minecraft:stone_bricks
fill ~-9 ~0 ~-6 ~-9 ~0 ~6 minecraft:stone_bricks
fill ~-8 ~0 ~-7 ~-8 ~0 ~7 minecraft:stone_bricks
fill ~-7 ~0 ~-8 ~-7 ~0 ~8 minecraft:stone_bricks
fill ~-6 ~0 ~-9 ~-6 ~0 ~9 minecraft:stone_bricks
fill ~-5 ~0 ~-10 ~-5 ~0 ~10 minecraft:stone_bricks
fill ~-4 ~0 ~-10 ~-4 ~0 ~10 minecraft:stone_bricks
fill ~-3 ~0 ~-10 ~-3 ~0 ~10 minecraft:stone_bricks
fill ~-2 ~0 ~-10 ~-2 ~0 ~10 minecraft:stone_bricks
fill ~-1 ~0 ~-10 ~-1 ~0 ~10 minecraft:stone_bricks
fill ~0 ~0 ~-10 ~0 ~0 ~10 minecraft:stone_bricks
fill ~1 ~0 ~-10 ~1 ~0 ~10 minecraft:stone_bricks
fill ~2 ~0 ~-10 ~2 ~0 ~10 minecraft:stone_bricks
fill ~3 ~0 ~-10 ~3 ~0 ~10 minecraft:stone_bricks
fill ~4 ~0 ~-10 ~4 ~0 ~10 minecraft:stone_bricks
fill ~5 ~0 ~-10 ~5 ~0 ~10 minecraft:stone_bricks
fill ~6 ~0 ~-9 ~6 ~0 ~9 minecraft:stone_bricks
fill ~7 ~0 ~-8 ~7 ~0 ~8 minecraft:stone_bricks
fill ~8 ~0 ~-7 ~8 ~0 ~7 minecraft:stone_bricks
fill ~9 ~0 ~-6 ~9 ~0 ~6 minecraft:stone_bricks
fill ~10 ~0 ~-5 ~10 ~0 ~5 minecraft:stone_bricks
fill ~-9 ~0 ~-5 ~-9 ~0 ~5 minecraft:air
fill ~-8 ~0 ~-6 ~-8 ~0 ~6 minecraft:air
fill ~-7 ~0 ~-7 ~-7 ~0 ~7 minecraft:air
fill ~-6 ~0 ~-8 ~-6 ~0 ~8 minecraft:air
fill ~-5 ~0 ~-9 ~-5 ~0 ~9 minecraft:air
fill ~-4 ~0 ~-9 ~-4 ~0 ~9 minecraft:air
fill ~-3 ~0 ~-9 ~-3 ~0 ~9 minecraft:air
fill ~-2 ~0 ~-9 ~-2 ~0 ~9 minecraft:air
fill ~-1 ~0 ~-9 ~-1 ~0 ~9 minecraft:air
fill ~0 ~0 ~-9 ~0 ~0 ~9 minecraft:air
fill ~1 ~0 ~-9 ~1 ~0 ~9 minecraft:air
fill ~2 ~0 ~-9 ~2 ~0 ~9 minecraft:air
fill ~3 ~0 ~-9 ~3 ~0 ~9 minecraft:air
fill ~4 ~0 ~-9 ~4 ~0 ~9 minecraft:air
fill ~5 ~0 ~-9 ~5 ~0 ~9 minecraft:air
fill ~6 ~0 ~-8 ~6 ~0 ~8 minecraft:air
fill ~7 ~0 ~-7 ~7 ~0 ~7 minecraft:air
fill ~8 ~0 ~-6 ~8 ~0 ~6 minecraft:air
fill ~9 ~0 ~-5 ~9 ~0 ~5 minecraft:air
setblock ~11 ~0 ~5 minecraft:polished_blackstone_bricks
setblock ~11 ~0 ~-5 minecraft:polished_blackstone_bricks
setblock ~-11 ~0 ~5 minecraft:polished_blackstone_bricks
setblock ~-11 ~0 ~-5 minecraft:polished_blackstone_bricks
setblock ~5 ~0 ~11 minecraft:polished_blackstone_bricks
setblock ~5 ~0 ~-11 minecraft:polished_blackstone_bricks
setblock ~-5 ~0 ~11 minecraft:polished_blackstone_bricks
setblock ~-5 ~0 ~-11 minecraft:polished_blackstone_bricks
setblock ~11 ~0 ~4 minecraft:polished_blackstone_bricks
setblock ~11 ~0 ~-4 minecraft:polished_blackstone_bricks
setblock ~-11 ~0 ~4 minecraft:polished_blackstone_bricks
setblock ~-11 ~0 ~-4 minecraft:polished_blackstone_bricks
setblock ~4 ~0 ~11 minecraft:polished_blackstone_bricks
setblock ~4 ~0 ~-11 minecraft:polished_blackstone_bricks
setblock ~-4 ~0 ~11 minecraft:polished_blackstone_bricks
setblock ~-4 ~0 ~-11 minecraft:polished_blackstone_bricks
fill ~-1 ~0 ~-1 ~1 ~0 ~1 minecraft:polished_blackstone_bricks
