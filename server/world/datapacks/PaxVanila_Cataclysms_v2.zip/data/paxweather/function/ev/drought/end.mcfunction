tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Пошёл первый дождик. Засуха кончилась.", "color": "green"}]
weather rain 120s
