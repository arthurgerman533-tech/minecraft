tp @s ~ ~-1.5 ~
particle minecraft:flame ~ ~ ~ 0.4 0.4 0.4 0.02 12 force
particle minecraft:large_smoke ~ ~0.8 ~ 0.3 0.6 0.3 0.01 6 force
particle minecraft:lava ~ ~ ~ 0.3 0.3 0.3 0 2 force
scoreboard players remove @s pxw_mt 1
execute if score @s pxw_mt matches ..0 at @s run function paxweather:ev/meteor/impact
