tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Шторм ушёл в открытое море.", "color": "green"}]
weather clear 300s
kill @e[type=minecraft:drowned,tag=pxw_mob]
