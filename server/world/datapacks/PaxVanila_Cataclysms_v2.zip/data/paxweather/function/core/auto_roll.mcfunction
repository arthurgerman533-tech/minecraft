function paxweather:util/reset_next
execute unless entity @a[tag=pxw_t] unless entity @a[tag=pxw_sp] run return 0
execute store result score #r pxw run random value 1..100
execute if score #r pxw matches 1..14 run scoreboard players set #pending pxw 1
execute if score #r pxw matches 15..24 run scoreboard players set #pending pxw 2
execute if score #r pxw matches 25..34 run scoreboard players set #pending pxw 3
execute if score #r pxw matches 35..42 run scoreboard players set #pending pxw 4
execute if score #r pxw matches 43..52 run scoreboard players set #pending pxw 5
execute if score #r pxw matches 53..64 run scoreboard players set #pending pxw 6
execute if score #r pxw matches 65..72 run scoreboard players set #pending pxw 7
execute if score #r pxw matches 73..82 run scoreboard players set #pending pxw 8
execute if score #r pxw matches 83..90 run scoreboard players set #pending pxw 9
execute if score #r pxw matches 91..100 run scoreboard players set #pending pxw 10
execute store result score #s pxw run random value 1..3
execute unless entity @a[tag=pxw_t] run scoreboard players set #s pxw 1
execute if entity @a[tag=pxw_sp] if score #s pxw matches 1 run function paxweather:core/roll_space
scoreboard players set #warn pxw 61
function paxweather:core/warn_msg
