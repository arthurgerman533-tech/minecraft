tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Туман рассеялся. На земле остались чужие следы.", "color": "green"}]

execute as @a[tag=pxw_out,sort=random,limit=1] at @s run function paxweather:ev/fog/gift
