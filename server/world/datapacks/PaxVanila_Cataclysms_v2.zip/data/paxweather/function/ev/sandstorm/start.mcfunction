execute store result score #time pxw run random value 180..300
bossbar set paxweather:event name {"text": "≈ Песчаная буря", "color": "gold"}
bossbar set paxweather:event color yellow
title @a times 10 50 20
title @a subtitle {"text": "Песчаная буря в пустынях и бесплодных землях! В песке почти ничего не видно.", "color": "gray"}
title @a title {"text": "≈ Песчаная буря", "color": "gold", "bold": true}
tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Песчаная буря в пустынях и бесплодных землях! В песке почти ничего не видно.", "color": "gold"}]
