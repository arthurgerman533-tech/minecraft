execute if score #event pxw matches 1.. run function paxweather:core/end
scoreboard players set #pending pxw 1
scoreboard players set #warn pxw 11
function paxweather:ev/storm/warn
tellraw @s [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Запущено: Гроза (через 10 сек).", "color": "green"}]
