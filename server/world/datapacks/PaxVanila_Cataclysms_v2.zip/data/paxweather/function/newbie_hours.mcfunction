$scoreboard players set #newbie pxw $(h)
scoreboard players set #k pxw 72000
scoreboard players operation #newbie pxw *= #k pxw
$tellraw @s [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Новички защищены первые $(h) ч. (время работы сервера).", "color": "green"}]
