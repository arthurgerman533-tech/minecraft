$scoreboard players set #a pxw $(min)
$scoreboard players set #b pxw $(max)
scoreboard players operation #a pxw *= #60 pxw
scoreboard players operation #b pxw *= #60 pxw
execute if score #b pxw <= #a pxw run scoreboard players operation #b pxw += #60 pxw
execute store result storage paxweather:cfg min int 1 run scoreboard players get #a pxw
execute store result storage paxweather:cfg max int 1 run scoreboard players get #b pxw
function paxweather:util/reset_next
$tellraw @s [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Интервал: от $(min) до $(max) минут.", "color": "green"}]
