execute store result score #time pxw run random value 60..100
bossbar set paxweather:event name {"text": "▲ Землетрясение", "color": "red"}
bossbar set paxweather:event color red
title @a times 10 50 20
title @a subtitle {"text": "Землетрясение! Под землёй сыплются камни.", "color": "gray"}
title @a title {"text": "▲ Землетрясение", "color": "red", "bold": true}
tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Землетрясение! Под землёй сыплются камни.", "color": "red"}]
