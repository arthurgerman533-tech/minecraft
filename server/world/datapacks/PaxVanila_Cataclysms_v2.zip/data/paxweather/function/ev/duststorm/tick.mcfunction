execute as @a[tag=pxw_mars,tag=pxw_sout] at @s run function paxweather:ev/duststorm/in
execute if score #m20 pxw matches 0 run title @a[tag=pxw_sp,tag=!pxw_sout] actionbar {"text":"Снаружи красная мгла. Не выходи без нужды.","color":"red"}
execute if score #m20 pxw matches 10 run title @a[tag=pxw_moon] actionbar {"text":"С Луны видно: Марс затянуло красной пылью.","color":"red"}
