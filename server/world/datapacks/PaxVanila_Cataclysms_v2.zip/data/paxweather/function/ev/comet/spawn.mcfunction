summon minecraft:marker ~ ~ ~ {Tags:["pxw_spot"]}
spreadplayers ~ ~ 1 40 false @e[type=minecraft:marker,tag=pxw_spot]
execute at @e[type=minecraft:marker,tag=pxw_spot] run summon minecraft:block_display ~ ~39 ~ {Tags:["pxw_rock","pxw_rocknew","pxw_comet"],block_state:{Name:"minecraft:packed_ice"},teleport_duration:1,brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.75f,-0.75f,-0.75f],scale:[1.5f,1.5f,1.5f]}}
scoreboard players set @e[type=minecraft:block_display,tag=pxw_rocknew] pxw_mt 26
tag @e[type=minecraft:block_display,tag=pxw_rocknew] remove pxw_rocknew
kill @e[type=minecraft:marker,tag=pxw_spot]
