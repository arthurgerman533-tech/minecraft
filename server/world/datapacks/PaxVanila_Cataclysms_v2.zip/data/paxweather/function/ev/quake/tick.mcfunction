execute if score #m2 pxw matches 0 as @a[tag=pxw_t] at @s run rotate @s ~2.5 ~1.5
execute if score #m2 pxw matches 1 as @a[tag=pxw_t] at @s run rotate @s ~-2.5 ~-1.5
execute as @a[tag=pxw_t] at @s run particle minecraft:falling_dust{block_state:{Name:"minecraft:gravel"}} ~ ~3 ~ 5 2 5 0 50 normal @s
execute as @a[tag=pxw_t] at @s run particle minecraft:block{block_state:{Name:"minecraft:stone"}} ~ ~ ~ 4 0 4 0 40 normal @s
execute if score #m3 pxw matches 0 as @a[tag=pxw_t] at @s run playsound minecraft:block.deepslate.break block @s ~ ~-2 ~ 1 0.5
execute if score #m4 pxw matches 0 as @a[tag=pxw_t] at @s run playsound minecraft:entity.warden.dig hostile @s ~ ~-3 ~ 0.7 0.6
effect give @a[tag=pxw_t] minecraft:slowness 2 0 true
effect give @a[tag=pxw_t,tag=!pxw_out,y=-64,dy=114] minecraft:mining_fatigue 3 1 true
execute if score #m5 pxw matches 0 run title @a[tag=pxw_t,tag=!pxw_out,y=-64,dy=114] actionbar {"text":"Обвал! Беги наверх!","color":"red"}
execute if score #m5 pxw matches 0 as @a[tag=pxw_hurt,tag=!pxw_out,y=-64,dy=114] run damage @s 2 minecraft:falling_block
