effect give @s minecraft:slowness 2 1 true
execute if score #m6 pxw matches 0 run particle minecraft:bubble_column_up ~ ~ ~ 1 1 1 0 40 normal @s
execute if score #m12 pxw matches 0 if entity @s[tag=pxw_adult] store result score #cnt pxw if entity @e[type=minecraft:drowned,tag=pxw_mob]
execute if score #m12 pxw matches 0 if entity @s[tag=pxw_adult] if score #cnt pxw matches ..11 positioned ^ ^-1 ^-6 if block ~ ~ ~ minecraft:water run summon minecraft:drowned ~ ~ ~ {Tags:["pxw_mob"],CustomName:{"text":"Утопленник шторма","color":"blue"}}
