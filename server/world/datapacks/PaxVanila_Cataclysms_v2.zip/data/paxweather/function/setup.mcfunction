scoreboard players set #init pxw 1
scoreboard players set #auto pxw 1
scoreboard players set #event pxw 0
scoreboard players set #warn pxw 0
scoreboard players set #pending pxw 0
scoreboard players set #time pxw 0
scoreboard players set #newbie pxw 3456000
data modify storage paxweather:cfg min set value 2700
data modify storage paxweather:cfg max set value 5400
function paxweather:util/reset_next
