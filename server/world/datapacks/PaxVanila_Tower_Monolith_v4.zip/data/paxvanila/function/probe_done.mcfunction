kill @e[type=minecraft:marker,tag=pxprobe]
execute in minecraft:overworld run forceload remove 0 0
scoreboard players operation #t pxt = #mx pxt
scoreboard players operation #t pxt += #up pxt
tellraw @a [{"text":"[Башня] ","color":"gold"},{"text":"Самая высокая гора вокруг (до 256 блоков): Y=","color":"yellow"},{"score":{"name":"#mx","objective":"pxt"}}]
scoreboard players set #busy pxt 0
function paxvanila:start
