execute in minecraft:overworld positioned 48 0 0 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 44 0 18 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 34 0 34 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 18 0 44 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 0 0 48 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -18 0 44 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -34 0 34 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -44 0 18 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -48 0 0 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -44 0 -18 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -34 0 -34 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -18 0 -44 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 0 0 -48 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 18 0 -44 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 34 0 -34 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 44 0 -18 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
schedule function paxvanila:probe/r2 4t replace
