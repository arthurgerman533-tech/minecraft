execute if score #event pxw matches 1.. run function paxweather:core/end
scoreboard players set #pending pxw 5
scoreboard players set #warn pxw 11
function paxweather:ev/quake/warn
tellraw @s [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Запущено: Землетрясение (через 10 сек).", "color": "green"}]
