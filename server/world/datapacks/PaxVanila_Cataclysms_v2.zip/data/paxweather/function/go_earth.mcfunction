execute in minecraft:overworld run spreadplayers 120 0 1 40 false @s
function paxweather:util/grav_off
tellraw @s [{"text": "[Космос] ", "color": "aqua"}, {"text": "С возвращением на Землю.", "color": "gray"}]
