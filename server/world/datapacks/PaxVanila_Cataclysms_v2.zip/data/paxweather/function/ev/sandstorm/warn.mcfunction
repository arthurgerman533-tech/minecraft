tellraw @a [{"text": "≈ ", "color": "gold"}, {"text": "Песчаная буря. ", "color": "gold", "bold": true}, {"text": "В пустынях поднимается ветер. Через минуту песчаная буря.", "color": "gray"}]
execute as @a at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 0.6 0.6
