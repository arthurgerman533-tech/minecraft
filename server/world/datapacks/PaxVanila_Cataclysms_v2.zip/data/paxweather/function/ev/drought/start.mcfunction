execute store result score #time pxw run random value 300..480
bossbar set paxweather:event name {"text": "☀ Засуха", "color": "gold"}
bossbar set paxweather:event color yellow
title @a times 10 50 20
title @a subtitle {"text": "Засуха! Под открытым небом быстрее хочется есть.", "color": "gray"}
title @a title {"text": "☀ Засуха", "color": "gold", "bold": true}
tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Засуха! Под открытым небом быстрее хочется есть.", "color": "gold"}]
weather clear 900s
