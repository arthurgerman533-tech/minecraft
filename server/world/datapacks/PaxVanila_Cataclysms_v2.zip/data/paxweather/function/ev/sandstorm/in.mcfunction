particle minecraft:falling_dust{block_state:{Name:"minecraft:sand"}} ~ ~2 ~ 6 2 6 0 120 normal @s
particle minecraft:falling_dust{block_state:{Name:"minecraft:red_sand"}} ~ ~2 ~ 6 2 6 0 40 normal @s
effect give @s minecraft:slowness 3 0 true
execute if score #m8 pxw matches 0 run effect give @s minecraft:blindness 3 0 true
execute if score #m10 pxw matches 0 run playsound minecraft:weather.rain.above ambient @s ~ ~ ~ 0.8 0.5
execute if score #m12 pxw matches 0 if entity @s[tag=pxw_hurt] run damage @s 1 minecraft:generic
execute if score #m30 pxw matches 0 if entity @s[tag=pxw_adult] store result score #cnt pxw if entity @e[type=minecraft:husk,tag=pxw_sand]
execute if score #m30 pxw matches 0 if entity @s[tag=pxw_adult] if score #cnt pxw matches ..9 run function paxweather:ev/sandstorm/mob
