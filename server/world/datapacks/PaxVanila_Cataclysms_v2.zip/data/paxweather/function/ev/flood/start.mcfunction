execute store result score #time pxw run random value 180..300
bossbar set paxweather:event name {"text": "≋ Великий шторм", "color": "blue"}
bossbar set paxweather:event color blue
title @a times 10 50 20
title @a subtitle {"text": "Великий шторм! Вода тянет на дно, из глубин поднимаются утопленники.", "color": "gray"}
title @a title {"text": "≋ Великий шторм", "color": "blue", "bold": true}
tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Великий шторм! Вода тянет на дно, из глубин поднимаются утопленники.", "color": "blue"}]
weather thunder 600s
