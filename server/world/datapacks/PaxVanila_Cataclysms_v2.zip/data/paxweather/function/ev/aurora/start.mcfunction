execute store result score #time pxw run random value 180..300
bossbar set paxweather:event name {"text": "✦ Северное сияние", "color": "green"}
bossbar set paxweather:event color green
title @a times 10 50 20
title @a subtitle {"text": "Северное сияние! Под открытым небом удача и лечение.", "color": "gray"}
title @a title {"text": "✦ Северное сияние", "color": "green", "bold": true}
tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Северное сияние! Под открытым небом удача и лечение.", "color": "green"}]
weather clear 600s
tellraw @a [{"text": "Сеть Страж-7: ", "color": "aqua"}, {"text": "небо чистое. Отдохните, люди PAX.", "color": "gray"}]
