function paxweather:util/grav_off
attribute @s minecraft:gravity modifier add paxweather:low_gravity -0.0667 add_value
attribute @s minecraft:fall_damage_multiplier modifier add paxweather:low_gravity -0.8 add_multiplied_total
attribute @s minecraft:safe_fall_distance modifier add paxweather:low_gravity 9 add_value
tag @s add pxw_gmoon
title @s actionbar {"text":"Луна: гравитация 1/6. Прыгай!","color":"gray"}
