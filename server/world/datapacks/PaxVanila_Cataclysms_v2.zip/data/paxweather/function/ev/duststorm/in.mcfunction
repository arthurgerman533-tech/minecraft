particle minecraft:falling_dust{block_state:{Name:"minecraft:red_sand"}} ~ ~2 ~ 7 2 7 0 160 normal @s
particle minecraft:falling_dust{block_state:{Name:"minecraft:terracotta"}} ~ ~2 ~ 7 2 7 0 40 normal @s
effect give @s minecraft:slowness 3 0 true
execute if score #m8 pxw matches 0 run effect give @s minecraft:blindness 3 0 true
execute if score #m10 pxw matches 0 run playsound minecraft:weather.rain.above ambient @s ~ ~ ~ 0.8 0.4
execute if score #m12 pxw matches 0 if entity @s[tag=pxw_shurt] run damage @s 1 minecraft:generic
