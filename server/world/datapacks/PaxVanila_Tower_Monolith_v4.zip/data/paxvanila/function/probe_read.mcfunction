tp @e[type=minecraft:marker,tag=pxprobe,limit=1] ~ ~ ~
execute store result score #p pxt run data get entity @e[type=minecraft:marker,tag=pxprobe,limit=1] Pos[1]
execute in minecraft:overworld run tp @e[type=minecraft:marker,tag=pxprobe,limit=1] 0 0 0
