tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Луна затихла.", "color": "green"}]
