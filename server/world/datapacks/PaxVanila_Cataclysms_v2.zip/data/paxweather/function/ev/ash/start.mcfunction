execute store result score #time pxw run random value 240..300
bossbar set paxweather:event name {"text": "☠ Пепельная ночь", "color": "dark_red"}
bossbar set paxweather:event color red
title @a times 10 50 20
title @a subtitle {"text": "Пепельная ночь! Год Пепла напоминает о себе: пепел жжёт, из пепла встают Пепельные.", "color": "gray"}
title @a title {"text": "☠ Пепельная ночь", "color": "dark_red", "bold": true}
tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Пепельная ночь! Год Пепла напоминает о себе: пепел жжёт, из пепла встают Пепельные.", "color": "dark_red"}]
weather thunder 600s
tellraw @a [{"text": "Монолит на 0,0: ", "color": "dark_red"}, {"text": "шестая строка под щитом светится красным. Печать держится, но трещит.", "color": "gray"}]
