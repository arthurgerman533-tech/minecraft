tellraw @a [{"text": "✦ ", "color": "green"}, {"text": "Северное сияние. ", "color": "green", "bold": true}, {"text": "Сеть Страж-7: магнитное поле спокойно. Сегодня будет сияние.", "color": "gray"}]
execute as @a at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 0.6 0.6
