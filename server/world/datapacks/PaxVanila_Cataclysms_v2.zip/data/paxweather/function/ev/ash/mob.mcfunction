function paxweather:util/spot
execute at @e[type=minecraft:marker,tag=pxw_spot] run summon minecraft:husk ~ ~ ~ {Tags:["pxw_mob","pxw_ash"],CustomName:{"text":"Пепельный","color":"dark_gray"},active_effects:[{id:"minecraft:fire_resistance",duration:-1,amplifier:0b,show_particles:0b}]}
execute at @e[type=minecraft:marker,tag=pxw_spot] run particle minecraft:large_smoke ~ ~1 ~ 0.5 1 0.5 0.02 30 force
kill @e[type=minecraft:marker,tag=pxw_spot]
