execute store result storage paxvanila:t a.y int 1 run scoreboard players get #t pxt
data modify storage paxvanila:t a.f set value "top_floor"
function paxvanila:at with storage paxvanila:t a
scoreboard players operation #h pxt = #t pxt
scoreboard players operation #h pxt -= #g pxt
scoreboard players remove #h pxt 2
scoreboard players operation #h pxt %= #24 pxt
execute store result storage paxvanila:t a.k int 1 run scoreboard players get #h pxt
execute store result storage paxvanila:t a.y int 1 run scoreboard players get #t pxt
function paxvanila:hole with storage paxvanila:t a
execute store result storage paxvanila:t a.y int 1 run scoreboard players get #t pxt
data modify storage paxvanila:t a.f set value "clear_top"
function paxvanila:at with storage paxvanila:t a
execute store result storage paxvanila:t a.y int 1 run scoreboard players get #t pxt
data modify storage paxvanila:t a.f set value "crown"
function paxvanila:at with storage paxvanila:t a
execute store result storage paxvanila:t a.y int 1 run scoreboard players get #g pxt
data modify storage paxvanila:t a.f set value "door"
function paxvanila:at with storage paxvanila:t a
execute store result storage paxvanila:t a.y int 1 run scoreboard players get #g pxt
data modify storage paxvanila:t a.f set value "hall"
function paxvanila:at with storage paxvanila:t a
function paxvanila:guards
function paxvanila:spawn
execute in minecraft:overworld run forceload remove -32 -32 31 31
scoreboard players set #busy pxt 0
tellraw @a [{"text":"[Башня] ","color":"gold"},{"text":"Монолит готов! Спавн: 0 ","color":"green"},{"score":{"name":"#sy","objective":"pxt"}},{"text":" 6"}]
