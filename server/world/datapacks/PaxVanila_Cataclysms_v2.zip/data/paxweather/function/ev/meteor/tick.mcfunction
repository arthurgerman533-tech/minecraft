execute as @a[tag=pxw_out] at @s run particle minecraft:end_rod ~ ~30 ~ 20 4 20 0.02 8 normal @s
execute if score #m4 pxw matches 0 as @a[tag=pxw_out,sort=random,limit=1] at @s run function paxweather:ev/meteor/spawn
execute if score #m10 pxw matches 5 as @a[tag=pxw_out,sort=random,limit=1] at @s run function paxweather:ev/meteor/spawn
