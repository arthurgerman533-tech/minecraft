$data modify storage paxvanila:t a.f set value "$(f)"
function paxvanila:at with storage paxvanila:t a
