attribute @s minecraft:gravity modifier remove paxweather:low_gravity
attribute @s minecraft:fall_damage_multiplier modifier remove paxweather:low_gravity
attribute @s minecraft:safe_fall_distance modifier remove paxweather:low_gravity
tag @s remove pxw_gmoon
tag @s remove pxw_gmars
