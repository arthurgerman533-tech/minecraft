title @s actionbar {"text":"Минус сто пятьдесят! В базу или надень кожаную броню.","color":"aqua"}
playsound minecraft:entity.player.hurt_freeze player @s ~ ~ ~ 0.6 1
execute if entity @s[tag=pxw_shurt] run damage @s 1 minecraft:freeze
