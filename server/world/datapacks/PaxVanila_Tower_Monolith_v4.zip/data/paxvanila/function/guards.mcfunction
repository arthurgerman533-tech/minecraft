scoreboard objectives add pxt dummy
execute unless score #g pxt = #g pxt run return run tellraw @s {"text":"[Башня] Сначала построй башню.","color":"red"}
execute in minecraft:overworld if entity @e[type=minecraft:iron_golem,tag=pxguard,x=-24,y=-64,z=-24,dx=48,dy=400,dz=48] run return run tellraw @a {"text":"[Башня] Стражи уже на посту.","color":"gray"}
scoreboard players operation #gy pxt = #g pxt
scoreboard players add #gy pxt 1
execute store result storage paxvanila:t a.y int 1 run scoreboard players get #gy pxt
function paxvanila:guards_at with storage paxvanila:t a
tellraw @a [{"text":"[Башня] ","color":"gold"},{"text":"У входа в монолит встали 4 Стража башни.","color":"green"}]
