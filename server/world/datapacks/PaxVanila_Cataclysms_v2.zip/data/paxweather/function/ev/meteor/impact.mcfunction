particle minecraft:explosion ~ ~ ~ 1.5 0.5 1.5 0 8 force
execute unless entity @s[tag=pxw_comet] run particle minecraft:flame ~ ~0.5 ~ 1 0.5 1 0.15 80 force
execute if entity @s[tag=pxw_comet] run particle minecraft:snowflake ~ ~0.5 ~ 1 0.5 1 0.15 80 force
particle minecraft:campfire_cosmic_smoke ~ ~0.5 ~ 1 0.5 1 0.02 25 force
particle minecraft:end_rod ~ ~0.5 ~ 0.5 0.5 0.5 0.2 30 force
playsound minecraft:entity.generic.explode ambient @a[distance=..64] ~ ~ ~ 2 0.8
playsound minecraft:block.amethyst_block.resonate ambient @a[distance=..32] ~ ~ ~ 2 0.6
execute as @a[tag=pxw_hurt,distance=..4,scores={pxw_hp=12..}] run damage @s 4 minecraft:explosion
execute as @a[tag=pxw_shurt,distance=..4,scores={pxw_hp=12..}] run damage @s 4 minecraft:explosion
effect give @a[distance=..6] minecraft:nausea 4 0 true
execute unless entity @s[tag=pxw_comet] run loot spawn ~ ~0.5 ~ loot paxweather:meteor
execute if entity @s[tag=pxw_comet] run loot spawn ~ ~0.5 ~ loot paxweather:comet
kill @s
