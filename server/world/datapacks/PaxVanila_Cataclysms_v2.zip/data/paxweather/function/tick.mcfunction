execute if entity @e[type=minecraft:block_display,tag=pxw_rock,limit=1] run function paxweather:ev/meteor/fall_tick
