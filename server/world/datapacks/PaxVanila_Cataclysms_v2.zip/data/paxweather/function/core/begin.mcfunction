execute if score #pending pxw matches 0 run scoreboard players set #warn pxw 0
execute if score #pending pxw matches 0 run return 0
execute if score #event pxw matches 1.. run function paxweather:core/end
scoreboard players operation #event pxw = #pending pxw
scoreboard players set #pending pxw 0
scoreboard players set #warn pxw 0
execute if score #event pxw matches 1 run function paxweather:ev/storm/start
execute if score #event pxw matches 2 run function paxweather:ev/blizzard/start
execute if score #event pxw matches 3 run function paxweather:ev/drought/start
execute if score #event pxw matches 4 run function paxweather:ev/sandstorm/start
execute if score #event pxw matches 5 run function paxweather:ev/quake/start
execute if score #event pxw matches 6 run function paxweather:ev/meteor/start
execute if score #event pxw matches 7 run function paxweather:ev/ash/start
execute if score #event pxw matches 8 run function paxweather:ev/flood/start
execute if score #event pxw matches 9 run function paxweather:ev/fog/start
execute if score #event pxw matches 10 run function paxweather:ev/aurora/start
execute if score #event pxw matches 11 run function paxweather:ev/flare/start
execute if score #event pxw matches 12 run function paxweather:ev/meteorstorm/start
execute if score #event pxw matches 13 run function paxweather:ev/duststorm/start
execute if score #event pxw matches 14 run function paxweather:ev/dustdevil/start
execute if score #event pxw matches 15 run function paxweather:ev/moonquake/start
execute if score #event pxw matches 16 run function paxweather:ev/lunarnight/start
execute if score #event pxw matches 17 run function paxweather:ev/magstorm/start
execute if score #event pxw matches 18 run function paxweather:ev/comet/start
execute store result bossbar paxweather:event max run scoreboard players get #time pxw
execute store result bossbar paxweather:event value run scoreboard players get #time pxw
scoreboard players set #sp pxw 0
execute if score #event pxw matches 11..18 run scoreboard players set #sp pxw 1
function paxweather:core/bar_players
bossbar set paxweather:event visible true
