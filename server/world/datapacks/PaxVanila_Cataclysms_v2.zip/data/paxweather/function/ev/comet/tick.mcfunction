execute as @a[tag=pxw_out] at @s run particle minecraft:end_rod ~15 ~40 ~ 12 1 3 0.04 30 normal @s
execute as @a[tag=pxw_out] at @s run particle minecraft:soul_fire_flame ~15 ~40 ~ 12 1 3 0.02 15 normal @s
execute as @a[tag=pxw_sout] at @s run particle minecraft:end_rod ~15 ~30 ~ 12 1 3 0.04 40 normal @s
execute if score #m20 pxw matches 0 run effect give @a[tag=pxw_out] minecraft:luck 30 0 true
execute if score #m20 pxw matches 0 run effect give @a[tag=pxw_sout] minecraft:luck 30 0 true
execute if score #m10 pxw matches 0 as @a[tag=pxw_sout,sort=random,limit=1] at @s run function paxweather:ev/comet/spawn
