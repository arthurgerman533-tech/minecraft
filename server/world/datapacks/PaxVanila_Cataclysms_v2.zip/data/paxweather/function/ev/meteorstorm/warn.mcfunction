tellraw @a [{"text": "☄ ", "color": "light_purple"}, {"text": "Метеоритный шторм. ", "color": "light_purple", "bold": true}, {"text": "Сеть Страж-7: рой камней идёт к Луне и Марсу. Атмосферы нет, укрыться нечем.", "color": "gray"}]
execute as @a[tag=pxw_sp] at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 0.6 0.6
