execute if score #event pxw matches 1.. run function paxweather:core/end
scoreboard players set #pending pxw 7
scoreboard players set #warn pxw 11
function paxweather:ev/ash/warn
tellraw @s [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Запущено: Пепельная ночь (через 10 сек).", "color": "green"}]
