tellraw @a [{"text": "≋ ", "color": "blue"}, {"text": "Великий шторм. ", "color": "blue", "bold": true}, {"text": "Море чернеет. Через минуту великий шторм: моряки, к берегу!", "color": "gray"}]
execute as @a at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 0.6 0.6
