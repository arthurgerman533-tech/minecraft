execute if score #event pxw matches 1.. run function paxweather:core/end
function paxweather:core/roll_space
scoreboard players set #warn pxw 11
function paxweather:core/warn_msg
