execute store result score #time pxw run random value 120..200
bossbar set paxweather:event name {"text": "☼ Солнечная вспышка", "color": "yellow"}
bossbar set paxweather:event color yellow
title @a[tag=pxw_sp] times 10 50 20
title @a[tag=pxw_sp] subtitle {"text": "Солнечная вспышка! На поверхности Луны и Марса жжёт радиация. Спасает крыша.", "color": "gray"}
title @a[tag=pxw_sp] title {"text": "☼ Солнечная вспышка", "color": "yellow", "bold": true}
tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Солнечная вспышка! На поверхности Луны и Марса жжёт радиация. Спасает крыша.", "color": "yellow"}]
