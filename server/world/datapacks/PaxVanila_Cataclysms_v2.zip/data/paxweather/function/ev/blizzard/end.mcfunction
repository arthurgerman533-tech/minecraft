tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Метель стихла.", "color": "green"}]
weather clear 300s
kill @e[type=minecraft:stray,tag=pxw_mob]
