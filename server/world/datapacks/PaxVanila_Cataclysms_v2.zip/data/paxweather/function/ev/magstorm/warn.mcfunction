tellraw @a [{"text": "≋ ", "color": "dark_aqua"}, {"text": "Магнитная буря. ", "color": "dark_aqua", "bold": true}, {"text": "Сеть Страж-7: магнитное поле ш-ш-шумит. Мои машины могут сбоить.", "color": "gray"}]
execute as @a at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 0.6 0.6
