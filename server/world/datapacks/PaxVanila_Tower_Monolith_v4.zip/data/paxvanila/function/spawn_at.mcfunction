$execute in minecraft:overworld run setworldspawn 0 $(y) 6
