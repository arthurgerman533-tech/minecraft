scoreboard players set #auto pxw 1
function paxweather:util/reset_next
tellraw @s [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Авто-катаклизмы включены.", "color": "green"}]
