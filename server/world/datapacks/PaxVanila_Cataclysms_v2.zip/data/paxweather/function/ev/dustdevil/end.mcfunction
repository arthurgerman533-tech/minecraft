tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Вихри улеглись.", "color": "green"}]
