$execute in minecraft:overworld positioned 0 $(y) 0 run function paxmono:$(f)
