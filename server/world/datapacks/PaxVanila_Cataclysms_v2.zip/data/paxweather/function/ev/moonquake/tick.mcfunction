execute if score #m2 pxw matches 0 as @a[tag=pxw_moon] at @s run rotate @s ~2.5 ~1.5
execute if score #m2 pxw matches 1 as @a[tag=pxw_moon] at @s run rotate @s ~-2.5 ~-1.5
execute as @a[tag=pxw_moon] at @s run particle minecraft:block{block_state:{Name:"minecraft:light_gray_concrete_powder"}} ~ ~ ~ 5 0 5 0 50 normal @s
execute as @a[tag=pxw_moon] at @s run particle minecraft:falling_dust{block_state:{Name:"minecraft:andesite"}} ~ ~3 ~ 5 2 5 0 40 normal @s
execute if score #m3 pxw matches 0 as @a[tag=pxw_moon] at @s run playsound minecraft:block.bell.resonate block @s ~ ~-3 ~ 0.6 0.5
execute if score #m4 pxw matches 0 as @a[tag=pxw_moon] at @s run playsound minecraft:block.deepslate.break block @s ~ ~-2 ~ 1 0.4
effect give @a[tag=pxw_moon] minecraft:slowness 2 0 true
execute if score #m5 pxw matches 0 run title @a[tag=pxw_moon,tag=!pxw_sout] actionbar {"text":"Своды трещат! Наружу!","color":"red"}
execute if score #m5 pxw matches 0 as @a[tag=pxw_moon,tag=pxw_shurt,tag=!pxw_sout] run damage @s 2 minecraft:falling_block
