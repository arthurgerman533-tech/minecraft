title @s actionbar {"text":"Ты на вершине! Молния ищет высокие места.","color":"yellow"}
particle minecraft:electric_spark ~ ~1 ~ 0.5 1 0.5 0.3 60 normal @s
playsound minecraft:item.trident.thunder weather @s ~ ~ ~ 0.8 1.2
execute if entity @s[tag=pxw_hurt] run damage @s 2 minecraft:lightning_bolt
