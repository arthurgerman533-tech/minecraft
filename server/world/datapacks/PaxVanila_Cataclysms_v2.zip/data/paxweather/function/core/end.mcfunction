execute if score #event pxw matches 1 run function paxweather:ev/storm/end
execute if score #event pxw matches 2 run function paxweather:ev/blizzard/end
execute if score #event pxw matches 3 run function paxweather:ev/drought/end
execute if score #event pxw matches 4 run function paxweather:ev/sandstorm/end
execute if score #event pxw matches 5 run function paxweather:ev/quake/end
execute if score #event pxw matches 6 run function paxweather:ev/meteor/end
execute if score #event pxw matches 7 run function paxweather:ev/ash/end
execute if score #event pxw matches 8 run function paxweather:ev/flood/end
execute if score #event pxw matches 9 run function paxweather:ev/fog/end
execute if score #event pxw matches 10 run function paxweather:ev/aurora/end
execute if score #event pxw matches 11 run function paxweather:ev/flare/end
execute if score #event pxw matches 12 run function paxweather:ev/meteorstorm/end
execute if score #event pxw matches 13 run function paxweather:ev/duststorm/end
execute if score #event pxw matches 14 run function paxweather:ev/dustdevil/end
execute if score #event pxw matches 15 run function paxweather:ev/moonquake/end
execute if score #event pxw matches 16 run function paxweather:ev/lunarnight/end
execute if score #event pxw matches 17 run function paxweather:ev/magstorm/end
execute if score #event pxw matches 18 run function paxweather:ev/comet/end
scoreboard players set #event pxw 0
scoreboard players set #time pxw 0
bossbar set paxweather:event visible false
kill @e[type=minecraft:marker,tag=pxw_spot]
kill @e[type=minecraft:block_display,tag=pxw_rock]
scoreboard players set #sp pxw 0
function paxweather:util/reset_next
