execute store result score #time pxw run random value 150..240
bossbar set paxweather:event name {"text": "≋ Магнитная буря", "color": "dark_aqua"}
bossbar set paxweather:event color green
title @a times 10 50 20
title @a subtitle {"text": "Магнитная буря! Над Землёй сияние, машины Стража-7 сбоят.", "color": "gray"}
title @a title {"text": "≋ Магнитная буря", "color": "dark_aqua", "bold": true}
tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Магнитная буря! Над Землёй сияние, машины Стража-7 сбоят.", "color": "dark_aqua"}]
