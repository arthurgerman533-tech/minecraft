function paxvanila:probe_read
execute if score #p pxt > #mx pxt run scoreboard players operation #mx pxt = #p pxt
