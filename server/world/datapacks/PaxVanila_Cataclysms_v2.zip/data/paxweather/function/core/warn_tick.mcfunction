scoreboard players remove #warn pxw 1
execute if score #warn pxw matches 30 run tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Катаклизм через 30 секунд!", "color": "yellow"}]
execute if score #warn pxw matches 10 run tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Катаклизм через 10 секунд!", "color": "red"}]
execute if score #warn pxw matches 0 run function paxweather:core/begin
