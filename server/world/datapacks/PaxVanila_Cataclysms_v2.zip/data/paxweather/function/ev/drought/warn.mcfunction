tellraw @a [{"text": "☀ ", "color": "gold"}, {"text": "Засуха. ", "color": "gold", "bold": true}, {"text": "Солнце жжёт всё сильнее. Через минуту засуха: запаситесь едой.", "color": "gray"}]
execute as @a at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 0.6 0.6
