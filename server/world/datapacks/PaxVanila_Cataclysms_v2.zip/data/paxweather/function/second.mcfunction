schedule function paxweather:second 1s replace
function paxweather:util/tag_players
execute if score #warn pxw matches 1.. run function paxweather:core/warn_tick
execute if score #event pxw matches 1.. run function paxweather:core/active_tick
execute if score #auto pxw matches 1 if score #event pxw matches 0 if score #warn pxw matches 0 run function paxweather:core/auto_tick
