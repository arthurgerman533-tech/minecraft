$execute in minecraft:overworld run summon minecraft:iron_golem 3 $(y) 14 {PlayerCreated:1b,PersistenceRequired:1b,Tags:["pxguard"],CustomName:'Страж башни',CustomNameVisible:1b,Rotation:[0f,0f]}
$execute in minecraft:overworld run summon minecraft:iron_golem -3 $(y) 14 {PlayerCreated:1b,PersistenceRequired:1b,Tags:["pxguard"],CustomName:'Страж башни',CustomNameVisible:1b,Rotation:[0f,0f]}
$execute in minecraft:overworld run summon minecraft:iron_golem 6 $(y) 13 {PlayerCreated:1b,PersistenceRequired:1b,Tags:["pxguard"],CustomName:'Страж башни',CustomNameVisible:1b,Rotation:[0f,0f]}
$execute in minecraft:overworld run summon minecraft:iron_golem -6 $(y) 13 {PlayerCreated:1b,PersistenceRequired:1b,Tags:["pxguard"],CustomName:'Страж башни',CustomNameVisible:1b,Rotation:[0f,0f]}
