fill ~-1 ~1 ~9 ~1 ~4 ~13 minecraft:air
fill ~-2 ~1 ~11 ~-2 ~5 ~11 minecraft:chiseled_polished_blackstone
fill ~2 ~1 ~11 ~2 ~5 ~11 minecraft:chiseled_polished_blackstone
fill ~-2 ~5 ~11 ~2 ~5 ~11 minecraft:chiseled_polished_blackstone
fill ~-1 ~0 ~12 ~1 ~0 ~16 minecraft:polished_blackstone_bricks
