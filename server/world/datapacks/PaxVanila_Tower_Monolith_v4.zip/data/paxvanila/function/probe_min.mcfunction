function paxvanila:probe_read
execute if score #p pxt < #mn pxt run scoreboard players operation #mn pxt = #p pxt
