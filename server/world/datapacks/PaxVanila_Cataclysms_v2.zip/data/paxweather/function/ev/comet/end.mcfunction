tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Комета ушла за край неба. Она вернётся.", "color": "green"}]
