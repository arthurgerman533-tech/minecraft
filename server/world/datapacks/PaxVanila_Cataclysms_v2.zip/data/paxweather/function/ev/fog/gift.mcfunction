loot give @s loot paxweather:nameless
tellraw @a [{"text":"В тумане ","color":"gray"},{"selector":"@s","color":"white"},{"text":" нашёл чужую вещь. Без имени.","color":"gray"}]
