scoreboard players set #warn pxw 0
scoreboard players set #pending pxw 0
execute if score #event pxw matches 1.. run function paxweather:core/end
weather clear 300s
tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Небо очистилось. Катаклизм остановлен.", "color": "green"}]
