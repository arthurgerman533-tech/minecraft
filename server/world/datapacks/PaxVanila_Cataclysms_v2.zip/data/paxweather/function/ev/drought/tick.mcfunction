execute if score #m2 pxw matches 0 as @a[tag=pxw_out] at @s run particle minecraft:white_ash ~ ~1 ~ 5 1 5 0 30 normal @s
execute if score #m5 pxw matches 0 as @a[tag=pxw_out] at @s run particle minecraft:small_flame ~ ~0.2 ~ 4 0 4 0 6 normal @s
execute if score #m15 pxw matches 0 run effect give @a[tag=pxw_out,tag=pxw_adult] minecraft:hunger 6 0 true
execute if score #m15 pxw matches 0 run title @a[tag=pxw_out] actionbar {"text":"Жара! Ищи тень и воду.","color":"gold"}
execute if score #m20 pxw matches 0 as @a[tag=pxw_out,tag=pxw_hurt,predicate=!paxweather:wet] at @s if predicate paxweather:sandy run damage @s 1 minecraft:hot_floor
