$data remove storage paxvanila:tpl $(name)
$tellraw @s [{"text":"[Шаблон] ","color":"gold"},{"text":"Шаблон $(name) удалён, сундук вернётся к стандартным вещам.","color":"gray"}]
