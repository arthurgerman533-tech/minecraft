execute in minecraft:overworld positioned 32 0 0 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 30 0 12 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 23 0 23 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 12 0 30 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 0 0 32 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -12 0 30 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -23 0 23 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -30 0 12 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -32 0 0 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -30 0 -12 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -23 0 -23 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -12 0 -30 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 0 0 -32 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 12 0 -30 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 23 0 -23 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 30 0 -12 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
schedule function paxvanila:probe/r1 4t replace
