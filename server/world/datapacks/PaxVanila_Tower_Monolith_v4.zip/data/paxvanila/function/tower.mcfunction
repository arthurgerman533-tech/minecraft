scoreboard objectives add pxt dummy
execute if score #busy pxt matches 1 run return run tellraw @s {"text":"[Башня] Уже строится. Сброс: /function paxvanila:reset","color":"red"}
$scoreboard players set #g pxt $(ground)
$scoreboard players set #t pxt $(top)
function paxvanila:start
