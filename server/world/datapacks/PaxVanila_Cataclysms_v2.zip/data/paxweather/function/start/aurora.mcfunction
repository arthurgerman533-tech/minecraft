execute if score #event pxw matches 1.. run function paxweather:core/end
scoreboard players set #pending pxw 10
scoreboard players set #warn pxw 11
function paxweather:ev/aurora/warn
tellraw @s [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Запущено: Северное сияние (через 10 сек).", "color": "green"}]
