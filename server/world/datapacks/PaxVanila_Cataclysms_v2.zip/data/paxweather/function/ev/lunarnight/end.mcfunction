tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Над Луной встаёт Солнце.", "color": "green"}]
