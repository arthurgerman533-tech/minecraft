execute as @a[tag=pxw_mars,tag=pxw_sout] at @s run particle minecraft:falling_dust{block_state:{Name:"minecraft:red_sand"}} ~ ~1 ~ 8 1 8 0 30 normal @s
execute if score #m6 pxw matches 0 as @a[tag=pxw_mars,tag=pxw_sout,sort=random,limit=1] at @s run function paxweather:ev/dustdevil/lift
