execute store result score #r pxw run random value 1..6
execute if score #r pxw matches 1 run title @a[tag=pxw_t] actionbar {"text": "…мы были здесь раньше…", "color": "dark_gray", "italic": true}
execute if score #r pxw matches 2 run title @a[tag=pxw_t] actionbar {"text": "…ты стоишь на нашем фундаменте…", "color": "dark_gray", "italic": true}
execute if score #r pxw matches 3 run title @a[tag=pxw_t] actionbar {"text": "…запомни своё имя…", "color": "dark_gray", "italic": true}
execute if score #r pxw matches 4 run title @a[tag=pxw_t] actionbar {"text": "…мы выбрали войну…", "color": "dark_gray", "italic": true}
execute if score #r pxw matches 5 run title @a[tag=pxw_t] actionbar {"text": "…у нас не осталось имён…", "color": "dark_gray", "italic": true}
execute if score #r pxw matches 6 run title @a[tag=pxw_t] actionbar {"text": "…печать — это выбор…", "color": "dark_gray", "italic": true}
execute as @a[tag=pxw_t,sort=random,limit=1] at @s run playsound minecraft:ambient.cave ambient @s ^ ^ ^-4 1 0.7
execute as @a[tag=pxw_t,sort=random,limit=1] at @s run playsound minecraft:entity.enderman.ambient hostile @s ^ ^ ^-8 0.4 0.5
