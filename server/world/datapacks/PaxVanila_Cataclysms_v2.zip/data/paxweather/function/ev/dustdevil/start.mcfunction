execute store result score #time pxw run random value 120..180
bossbar set paxweather:event name {"text": "@ Пыльные вихри", "color": "gold"}
bossbar set paxweather:event color red
title @a[tag=pxw_sp] times 10 50 20
title @a[tag=pxw_sp] subtitle {"text": "Пыльные вихри! Подхватывают колонистов и подкидывают вверх.", "color": "gray"}
title @a[tag=pxw_sp] title {"text": "@ Пыльные вихри", "color": "gold", "bold": true}
tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Пыльные вихри! Подхватывают колонистов и подкидывают вверх.", "color": "gold"}]
