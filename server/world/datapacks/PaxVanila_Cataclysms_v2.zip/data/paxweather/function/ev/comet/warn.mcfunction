tellraw @a [{"text": "✧ ", "color": "aqua"}, {"text": "Комета. ", "color": "aqua", "bold": true}, {"text": "Сеть Страж-7: вижу хвостатую звезду. Красиво. И, кажется, она что-то роняет.", "color": "gray"}]
execute as @a at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 0.6 0.6
