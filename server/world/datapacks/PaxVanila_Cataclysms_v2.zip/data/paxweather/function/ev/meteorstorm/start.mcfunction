execute store result score #time pxw run random value 120..180
bossbar set paxweather:event name {"text": "☄ Метеоритный шторм", "color": "light_purple"}
bossbar set paxweather:event color purple
title @a[tag=pxw_sp] times 10 50 20
title @a[tag=pxw_sp] subtitle {"text": "Метеоритный шторм! Камни падают часто: в них лут и Звёздные осколки.", "color": "gray"}
title @a[tag=pxw_sp] title {"text": "☄ Метеоритный шторм", "color": "light_purple", "bold": true}
tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Метеоритный шторм! Камни падают часто: в них лут и Звёздные осколки.", "color": "light_purple"}]
