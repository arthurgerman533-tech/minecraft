execute as @a[tag=pxw_sout] at @s run particle minecraft:end_rod ~ ~3 ~ 6 3 6 0.03 40 normal @s
execute as @a[tag=pxw_sout] at @s run particle minecraft:wax_off ~ ~1 ~ 4 2 4 0 20 normal @s
effect give @a[tag=pxw_sout] minecraft:glowing 2 0 true
execute if score #m5 pxw matches 0 run title @a[tag=pxw_sout] actionbar {"text":"Радиация! Встань под крышу.","color":"yellow"}
execute if score #m5 pxw matches 0 as @a[tag=pxw_sout,tag=pxw_shurt] run damage @s 1 minecraft:magic
execute if score #m10 pxw matches 0 run effect give @a[tag=pxw_sout] minecraft:nausea 3 0 true
execute if score #m10 pxw matches 5 run title @a[tag=pxw_sp,tag=!pxw_sout] actionbar {"text":"Стрелки компасов пляшут. Снаружи вспышка.","color":"gold"}
execute if score #m3 pxw matches 0 as @a[tag=pxw_out] at @s run particle minecraft:end_rod ~ ~28 ~ 24 2 24 0.005 15 normal @s
