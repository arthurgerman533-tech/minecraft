tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Звёздный дождь закончился. Ищите упавшие осколки!", "color": "green"}]
