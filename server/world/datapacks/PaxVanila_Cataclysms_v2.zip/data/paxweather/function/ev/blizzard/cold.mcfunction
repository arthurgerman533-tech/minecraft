title @s actionbar {"text":"Холодно! Зайди под крышу или надень кожаную броню.","color":"aqua"}
playsound minecraft:entity.player.hurt_freeze player @s ~ ~ ~ 0.6 1
execute if entity @s[tag=pxw_hurt] run damage @s 1 minecraft:freeze
