tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Сеть Страж-7: связь восстановлена. Я снова вижу всех.", "color": "green"}]
