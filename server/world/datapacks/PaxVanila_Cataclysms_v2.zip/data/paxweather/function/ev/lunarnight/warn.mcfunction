tellraw @a [{"text": "☾ ", "color": "aqua"}, {"text": "Лунная ночь. ", "color": "aqua", "bold": true}, {"text": "Терминатор ползёт по Луне. Через минуту лунная ночь: включайте обогрев баз.", "color": "gray"}]
execute as @a[tag=pxw_sp] at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 0.6 0.6
