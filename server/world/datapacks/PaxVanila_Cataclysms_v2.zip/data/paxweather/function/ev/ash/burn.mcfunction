title @s actionbar {"text":"Горячий пепел! Встань под крышу или в воду.","color":"red"}
damage @s 1 minecraft:hot_floor
