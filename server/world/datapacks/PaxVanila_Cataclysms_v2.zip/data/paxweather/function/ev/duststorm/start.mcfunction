execute store result score #time pxw run random value 180..300
bossbar set paxweather:event name {"text": "≈ Пылевая буря Марса", "color": "red"}
bossbar set paxweather:event color red
title @a[tag=pxw_sp] times 10 50 20
title @a[tag=pxw_sp] subtitle {"text": "Пылевая буря на Марсе! Красная мгла, ничего не видно.", "color": "gray"}
title @a[tag=pxw_sp] title {"text": "≈ Пылевая буря Марса", "color": "red", "bold": true}
tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Пылевая буря на Марсе! Красная мгла, ничего не видно.", "color": "red"}]
