execute if score #event pxw matches 1.. run function paxweather:core/end
scoreboard players set #next pxw 0
scoreboard players set #auto pxw 1
function paxweather:core/auto_roll
scoreboard players set #warn pxw 11
