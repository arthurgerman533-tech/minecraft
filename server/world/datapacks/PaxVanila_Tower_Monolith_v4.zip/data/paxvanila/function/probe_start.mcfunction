kill @e[type=minecraft:marker,tag=pxprobe]
execute in minecraft:overworld run summon minecraft:marker 0 0 0 {Tags:["pxprobe"]}
execute if score #auto pxt matches 1 run function paxvanila:probe_ground
function paxvanila:probe/r0
