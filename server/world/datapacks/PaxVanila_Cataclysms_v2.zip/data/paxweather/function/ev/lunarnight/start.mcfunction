execute store result score #time pxw run random value 180..300
bossbar set paxweather:event name {"text": "☾ Лунная ночь", "color": "aqua"}
bossbar set paxweather:event color blue
title @a[tag=pxw_sp] times 10 50 20
title @a[tag=pxw_sp] subtitle {"text": "Лунная ночь! Холод космоса: нужна база или кожаная броня.", "color": "gray"}
title @a[tag=pxw_sp] title {"text": "☾ Лунная ночь", "color": "aqua", "bold": true}
tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Лунная ночь! Холод космоса: нужна база или кожаная броня.", "color": "aqua"}]
