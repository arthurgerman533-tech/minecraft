execute as @a[tag=pxw_out] at @s run particle minecraft:ash ~ ~3 ~ 7 3 7 0 120 normal @s
execute as @a[tag=pxw_out] at @s run particle minecraft:white_ash ~ ~3 ~ 7 3 7 0 50 normal @s
execute if score #m3 pxw matches 0 as @a[tag=pxw_out] at @s run particle minecraft:large_smoke ~ ~8 ~ 10 2 10 0.01 20 normal @s
execute if score #m20 pxw matches 0 run effect give @a[tag=pxw_out] minecraft:darkness 4 0 true
execute if score #m10 pxw matches 0 as @a[tag=pxw_out,tag=pxw_hurt,predicate=!paxweather:wet] run function paxweather:ev/ash/burn
execute in minecraft:overworld positioned 0 120 0 if entity @a[distance=..200] run particle minecraft:soul_fire_flame 0 120 0 0.6 40 0.6 0.02 80 force
execute if score #m5 pxw matches 0 in minecraft:overworld positioned 0 120 0 as @a[distance=..200] run playsound minecraft:block.respawn_anchor.deplete ambient @s 0 120 0 2 0.5
execute if score #m15 pxw matches 0 store result score #cnt pxw if entity @e[type=minecraft:husk,tag=pxw_ash]
execute if score #m15 pxw matches 0 if score #cnt pxw matches ..15 as @a[tag=pxw_adult,tag=pxw_out,sort=random,limit=3] at @s run function paxweather:ev/ash/mob
execute if score #time pxw matches 120 run tellraw @a [{"text": "Шёпот из-под Монолита: ", "color": "dark_red"}, {"text": "«…когда последний страж падёт…»", "color": "gray", "italic": true}]
execute if score #time pxw matches 60 run tellraw @a [{"text": "Сеть Страж-7: ", "color": "aqua"}, {"text": "печать держится. Я на посту.", "color": "gray"}]
