tellraw @a [{"text": "⚡ ", "color": "yellow"}, {"text": "Гроза. ", "color": "yellow", "bold": true}, {"text": "Небо темнеет. Через минуту гроза: прячьте скот, не стойте на вершинах.", "color": "gray"}]
execute as @a at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 0.6 0.6
