tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Пепел осел. Монолит снова молчит. Печать держится.", "color": "green"}]
weather clear 300s
kill @e[type=minecraft:husk,tag=pxw_mob,tag=pxw_ash]
