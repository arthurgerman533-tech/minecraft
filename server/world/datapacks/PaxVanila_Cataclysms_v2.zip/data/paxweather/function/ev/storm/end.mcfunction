tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Гроза прошла.", "color": "green"}]
weather clear 300s
