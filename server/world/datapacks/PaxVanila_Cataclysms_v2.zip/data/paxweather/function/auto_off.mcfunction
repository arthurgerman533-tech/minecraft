scoreboard players set #auto pxw 0
tellraw @s [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Авто-катаклизмы выключены. Ручной запуск работает.", "color": "yellow"}]
