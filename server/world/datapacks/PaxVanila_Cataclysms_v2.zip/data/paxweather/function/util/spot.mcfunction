summon minecraft:marker ~ ~ ~ {Tags:["pxw_spot"]}
spreadplayers ~ ~ 1 24 false @e[type=minecraft:marker,tag=pxw_spot]
execute in minecraft:overworld run kill @e[type=minecraft:marker,tag=pxw_spot,x=-48,y=-64,z=-48,dx=96,dy=400,dz=96]
