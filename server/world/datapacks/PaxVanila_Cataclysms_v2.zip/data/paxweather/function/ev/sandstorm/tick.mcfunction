execute as @a[tag=pxw_out] at @s if predicate paxweather:sandy run function paxweather:ev/sandstorm/in
execute if score #m20 pxw matches 0 run title @a[tag=pxw_out,predicate=!paxweather:sandy] actionbar {"text":"Где-то в пустынях бушует песчаная буря.","color":"gold"}
