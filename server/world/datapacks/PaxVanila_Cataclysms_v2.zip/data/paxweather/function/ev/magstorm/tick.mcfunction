execute as @a[tag=pxw_sp] at @s run particle minecraft:electric_spark ~ ~1 ~ 4 2 4 0.1 25 normal @s
execute if score #m15 pxw matches 0 run effect give @a[tag=pxw_sp] minecraft:darkness 3 0 true
execute if score #m4 pxw matches 0 run function paxweather:ev/magstorm/glitch
execute as @a[tag=pxw_out] at @s run particle minecraft:end_rod ~ ~28 ~ 24 2 24 0.005 25 normal @s
execute as @a[tag=pxw_out] at @s run particle minecraft:glow ~ ~24 ~ 24 3 24 0 30 normal @s
execute if score #m20 pxw matches 0 run title @a[tag=pxw_out] actionbar {"text":"Над Землёй магнитное сияние.","color":"green"}
