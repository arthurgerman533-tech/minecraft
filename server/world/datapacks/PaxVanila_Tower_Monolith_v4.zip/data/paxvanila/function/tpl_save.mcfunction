execute unless entity @e[type=minecraft:chest_minecart,distance=..6] run return run tellraw @s [{"text":"[Шаблон] ","color":"gold"},{"text":"Рядом нет вагонетки с сундуком (до 6 блоков).","color":"red"}]
$data modify storage paxvanila:tpl $(name) set from entity @e[type=minecraft:chest_minecart,sort=nearest,limit=1,distance=..6] Items
$tellraw @s [{"text":"[Шаблон] ","color":"gold"},{"text":"Сохранён шаблон $(name). Корабли будут класть эти вещи в свой сундук.","color":"green"}]
