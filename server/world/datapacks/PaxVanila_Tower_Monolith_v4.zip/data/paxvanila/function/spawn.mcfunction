scoreboard objectives add pxt dummy
execute unless score #g pxt = #g pxt run return run tellraw @s {"text":"[Башня] Сначала построй башню.","color":"red"}
scoreboard players operation #sy pxt = #g pxt
scoreboard players add #sy pxt 1
execute store result storage paxvanila:t a.y int 1 run scoreboard players get #sy pxt
function paxvanila:spawn_at with storage paxvanila:t a
