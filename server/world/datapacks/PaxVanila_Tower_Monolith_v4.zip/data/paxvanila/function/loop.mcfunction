function paxvanila:step
function paxvanila:step
function paxvanila:step
function paxvanila:step
execute if score #done pxt matches 0 run schedule function paxvanila:loop 1t replace
execute if score #done pxt matches 1 run function paxvanila:finish
