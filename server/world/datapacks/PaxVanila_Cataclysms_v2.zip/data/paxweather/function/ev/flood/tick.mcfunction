execute as @a[tag=pxw_out] at @s if predicate paxweather:sea run function paxweather:ev/flood/coast
execute as @a[tag=pxw_t] at @s if predicate paxweather:wet run function paxweather:ev/flood/water
execute if score #m20 pxw matches 0 run title @a[tag=pxw_out,predicate=!paxweather:sea] actionbar {"text":"Над морем бушует великий шторм.","color":"blue"}
