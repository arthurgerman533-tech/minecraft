execute as @a[tag=pxw_moon,tag=!pxw_gmoon] run function paxweather:util/grav_moon
execute as @a[tag=pxw_mars,tag=!pxw_gmars] run function paxweather:util/grav_mars
execute as @a[tag=pxw_gmoon,tag=!pxw_moon] run function paxweather:util/grav_off
execute as @a[tag=pxw_gmars,tag=!pxw_mars] run function paxweather:util/grav_off
