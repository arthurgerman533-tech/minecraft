execute as @e[type=minecraft:block_display,tag=pxw_rock] at @s run function paxweather:ev/meteor/fall
