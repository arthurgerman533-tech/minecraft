function paxweather:util/spot
execute at @e[type=minecraft:marker,tag=pxw_spot] run summon minecraft:husk ~ ~ ~ {Tags:["pxw_mob","pxw_sand"],CustomName:{"text":"Песчаный мертвец","color":"gold"}}
kill @e[type=minecraft:marker,tag=pxw_spot]
