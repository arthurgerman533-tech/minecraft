execute store result score #time pxw run random value 120..180
bossbar set paxweather:event name {"text": "✧ Комета", "color": "aqua"}
bossbar set paxweather:event color white
title @a times 10 50 20
title @a subtitle {"text": "Комета над PaxVanila! Под открытым небом удача, её осколки падают на Луну и Марс.", "color": "gray"}
title @a title {"text": "✧ Комета", "color": "aqua", "bold": true}
tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Комета над PaxVanila! Под открытым небом удача, её осколки падают на Луну и Марс.", "color": "aqua"}]
