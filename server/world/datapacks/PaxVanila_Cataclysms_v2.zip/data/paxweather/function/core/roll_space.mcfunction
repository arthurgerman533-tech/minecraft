execute store result score #r pxw run random value 1..96
execute if score #r pxw matches 1..14 run scoreboard players set #pending pxw 11
execute if score #r pxw matches 15..28 run scoreboard players set #pending pxw 12
execute if score #r pxw matches 29..40 run scoreboard players set #pending pxw 13
execute if score #r pxw matches 41..50 run scoreboard players set #pending pxw 14
execute if score #r pxw matches 51..62 run scoreboard players set #pending pxw 15
execute if score #r pxw matches 63..74 run scoreboard players set #pending pxw 16
execute if score #r pxw matches 75..86 run scoreboard players set #pending pxw 17
execute if score #r pxw matches 87..96 run scoreboard players set #pending pxw 18
