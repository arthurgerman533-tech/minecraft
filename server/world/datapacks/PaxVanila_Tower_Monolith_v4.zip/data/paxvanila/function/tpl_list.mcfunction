tellraw @s [{"text":"[Шаблон] Сохранённые шаблоны:","color":"gold"}]
data get storage paxvanila:tpl
