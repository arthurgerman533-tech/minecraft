execute if score #sp pxw matches 0 run bossbar set paxweather:event players @a
execute if score #sp pxw matches 1 run bossbar set paxweather:event players @a[tag=pxw_sp]
