tellraw @a [{"text": "@ ", "color": "gold"}, {"text": "Пыльные вихри. ", "color": "gold", "bold": true}, {"text": "На равнинах Марса закручиваются вихри. Держитесь за землю.", "color": "gray"}]
execute as @a[tag=pxw_sp] at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 0.6 0.6
