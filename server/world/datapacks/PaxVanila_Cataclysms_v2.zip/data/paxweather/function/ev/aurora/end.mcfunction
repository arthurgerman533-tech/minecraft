tellraw @a [{"text": "[Погода] ", "color": "dark_aqua"}, {"text": "Сияние погасло. Сеть Страж-7: запомните свои имена.", "color": "green"}]
