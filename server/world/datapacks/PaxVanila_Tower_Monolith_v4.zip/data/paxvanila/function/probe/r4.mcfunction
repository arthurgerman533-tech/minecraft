execute in minecraft:overworld positioned 128 0 0 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 118 0 49 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 91 0 91 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 49 0 118 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 0 0 128 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -49 0 118 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -91 0 91 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -118 0 49 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -128 0 0 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -118 0 -49 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -91 0 -91 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned -49 0 -118 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 0 0 -128 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 49 0 -118 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 91 0 -91 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
execute in minecraft:overworld positioned 118 0 -49 positioned over motion_blocking_no_leaves run function paxvanila:probe_max
schedule function paxvanila:probe/r5 4t replace
